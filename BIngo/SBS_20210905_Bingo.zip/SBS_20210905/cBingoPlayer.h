#pragma once
#include "cBingoBase.h"

class cBingoPlayer : public cBingoBase
{
public:
	//cBingoPlayer();

public:
	virtual int InputBingo();

	int PlayerInputBingo();

	virtual void PrintBingo(); // <- �����ε�
	

};


#pragma once

#define BIGOSIZE 5

class CoreFN
{
public:
	static void SwapVal(int& p_src, int& p_dest)
	{
		int tempval = p_src;
		p_src = p_dest;
		p_dest = tempval;
	}
};



class cBingo
{
public:
	void TestFN(); // �׽�Ʈ�� 

public:
	cBingo( bool p_isai, bool p_isrand = true );
	virtual ~cBingo();

	void InitBingo( bool p_isrand = true );
	int GetBingoCount();
	void PrintBingo();
	void UpdateBingoCount();
	void SetBingoData(int p_val);

	int InputBingo(); // �÷��̾�� input�޵��� ó�� // AI�϶��� �˾Ƽ� ó��

protected:
	int GetEaseAIVal();


protected:
	int m_Bingo2byarr[BIGOSIZE][BIGOSIZE] = { 0, };
	int m_BingoCount = 0;
	
	bool m_ISAi = false;

};


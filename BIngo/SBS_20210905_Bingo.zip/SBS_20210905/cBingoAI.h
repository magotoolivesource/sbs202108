#pragma once
#include "cBingoBase.h"

class cBingoAI : public cBingoBase
{
public:
	virtual int InputBingo();
	virtual void PrintBingo();

	int AIInput();

protected:
	int EasyAI();
	int HardAI();


protected:
	int m_SelectVal = -1;
};


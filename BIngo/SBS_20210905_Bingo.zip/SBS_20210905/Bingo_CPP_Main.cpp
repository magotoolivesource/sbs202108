#include <iostream>
#include <cstdlib> // c <stdlib.h>
#include <ctime> // c <time.h>
//#include "Bingo_C.h"
#include <Windows.h>
#include <cassert> // c <assert.h>
#include "cBingo.h" 
#include "cBingoPlayer.h"
#include "cBingoAI.h"


using namespace std;


// ������� ����
void OldCPPBingo()
{
	cBingo playerbingo(false);
	cBingo aibingo(true, false);

	//playerbingo.TestFN();
	int aival = -1;



	//int playerrandval[10] = { 10, 1, 5, 7, 9, 12, 7, 8, 19, 3 };
	//for (int i = 0; i < 10; i++)
	//{
	//	//int playerval = playerbingo.InputBingo();
	//	playerbingo.SetBingoData(playerrandval[i]);
	//	aibingo.SetBingoData(playerrandval[i]);
	//}

	//aibingo.GetBingoCount();
	//playerbingo.GetBingoCount();



	while (true)
	{
		system("cls");
		playerbingo.PrintBingo();
		cout << "�÷��̾� �������� : " << playerbingo.GetBingoCount() << endl;

		cout << endl << endl;
		cout << "------------ AI ����------ " << endl;
		aibingo.PrintBingo();
		cout << "AI �������� : " << aibingo.GetBingoCount() << endl;
		if (aival >= 0)
			cout << "AI �� ������ ��ȣ : " << aival << endl;


		// �÷��̾� ����
		int playerval = playerbingo.InputBingo();
		aibingo.SetBingoData(playerval);

		// AI ����
		aival = aibingo.InputBingo();
		playerbingo.SetBingoData(aival);
	}
}


void main()
{
	srand(time(NULL));

	OldCPPBingo();


}

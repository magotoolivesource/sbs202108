#pragma once

#define BIGOSIZE 5

class cBingoBase
{
public:
	cBingoBase(bool p_isrand = true);
	virtual ~cBingoBase();

	void InitBingo(bool p_isrand = true);
	int GetBingoCount();
	virtual void PrintBingo();
	void UpdateBingoCount();
	void SetBingoData(int p_val);

	virtual int InputBingo();

protected:
	int GetEaseAIVal();


protected:
	int m_Bingo2byarr[BIGOSIZE][BIGOSIZE];// = { 0, };
	int m_BingoCount = 0;

	bool m_ISAi = false;


public:
	static void SwapVal(int& p_src, int& p_dest)
	{
		int tempval = p_src;
		p_src = p_dest;
		p_dest = tempval;
	}
};



#include <iostream>
#include <cstdlib> // c <stdlib.h>
#include <ctime> // c <time.h>
#include <Windows.h>
#include <cassert> // c <assert.h>
#include "cBingoBase.h"
#include "cBingoPlayer.h"
#include "cBingoAI.h"



using namespace std;

#define PLAYERAT 0
#define ALLAICOUNT 2
#define ALLPLAYERCOUNT 3

void main()
{
	srand(time(NULL));


	cBingoPlayer* playerbingo = new cBingoPlayer();
	cBingoAI* aibingo = new cBingoAI();

	//cBingoBase* allbibgocls[] = { new cBingoPlayer() 
	//	, new cBingoAI() };

	cBingoBase* allbingocls[1 + ALLAICOUNT] = { nullptr, nullptr, nullptr };
	allbingocls[0] = playerbingo;
	allbingocls[1] = aibingo;
	allbingocls[2] = new cBingoAI();


	int allcount = 1 + ALLAICOUNT;
	while (true)
	{
		system("cls");

		//playerbingo->PrintBingo();
		//aibingo->PrintBingo();

		////int playerval = playerbingo->PlayerInputBingo();
		//int playerval = playerbingo->InputBingo();
		//aibingo->SetBingoData(playerval);

		//int aival = aibingo->InputBingo();
		//playerbingo->SetBingoData(aival);

		for (int i = 0; i < allcount; i++)
		{
			allbingocls[i]->PrintBingo();
		}

		for (int i = 0; i < allcount; i++)
		{
			int outval = allbingocls[i]->InputBingo();
			for (int j = 0; j < allcount; j++)
			{
				if (i != j)
				{
					allbingocls[j]->SetBingoData(outval);
				}
			}
		}


	}



}

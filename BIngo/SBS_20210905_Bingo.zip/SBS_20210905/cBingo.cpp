#include "cBingo.h"
#include <iostream>


using namespace std;
void cBingo::TestFN()
{
	cout << "TestFN Call" << endl;
}



void cBingo::PrintBingo()
{
	int* bingo2byarr = &m_Bingo2byarr[0][0];

	// ȭ�� ���
	for (int y = 0; y < 5; y++)
	{
		for (int x = 0; x < 5; x++)
		{
			if (bingo2byarr[(y * 5) + x] <= -1)
			{
				cout << "*" << '\t';
			}
			else
			{
				cout << bingo2byarr[(y * 5) + x] << '\t';
			}
		}
		cout << endl; // ���Ϳ�Ȱ
	}

}


int cBingo::GetBingoCount()
{
	UpdateBingoCount();
	return m_BingoCount;
}

void cBingo::UpdateBingoCount()
{
	int bingocount = 0;
	// ��ü������ �Ǿ��ִ°�

	int xline = 0;
	int yline = 0;
	for (int i = 0; i < 5; i++)
	{
		yline = xline = 0;

		for (int j = 0; j < 5; j++)
		{
			// x�� ���� �ڷ�
			if (m_Bingo2byarr[i][j] == -1)
			{
				++xline;
			}
			if (m_Bingo2byarr[j][i] == -1)
			{
				++yline;
			}
		}

		if (xline == 5)
		{
			++bingocount;
		}

		if (yline == 5)
		{
			++bingocount;
		}

	}


	// ũ�ν� �޻��, �������
	int tempcrossLT = 0;
	int tempcrossRT = 0;
	for (int i = 0; i < 5; i++)
	{
		if (m_Bingo2byarr[i][i] == -1)
		{
			++tempcrossLT;
		}
		if (m_Bingo2byarr[5 - i - 1][i] == -1)
		{
			++tempcrossRT;
		}
	}
	if (tempcrossLT == 5)
	{
		++bingocount;
	}
	if (tempcrossRT == 5)
	{
		++bingocount;
	}

	m_BingoCount = bingocount;
}

cBingo::cBingo(bool p_isai, bool p_isrand) : m_ISAi(p_isai)
	, m_BingoCount(0)
{
	//m_ISAi = p_isai;
	m_BingoCount = 0;

	InitBingo(p_isrand);
}

cBingo::~cBingo()
{
}

void cBingo::InitBingo(bool p_isrand)
{
	for (int y = 0; y < 5; y++)
	{
		for (int x = 0; x < 5; x++)
		{
			m_Bingo2byarr[y][x] = ((y * 5) + x) + 1;
		}
	}


	if (p_isrand)
	{
		for (int i = 0; i < 15; i++)
		{
			// ���� ��ġ
			int x = i % 5;
			int y = int(i / 5);

			// ������ġ
			int temprand = rand() % 25;
			int sx = temprand % 5;
			int sy = (int)(temprand / 5);

			// �� ���� 
			CoreFN::SwapVal(m_Bingo2byarr[y][x], m_Bingo2byarr[sy][sx]);
		}
	}

}

void cBingo::SetBingoData(int p_val)
{
	int* bingoarr = m_Bingo2byarr[0];
	for (int y = 0; y < 5; y++)
	{
		for (int x = 0; x < 5; x++)
		{
			if (bingoarr[y * BIGOSIZE + x] == p_val)
			{
				bingoarr[y * BIGOSIZE + x] = -1;
			}
		}
	}
}



int cBingo::InputBingo()
{
	int inputval = -1;

	if (m_ISAi)
	{
		inputval = this->GetEaseAIVal();
	}
	else
	{
		//  �÷��̾� ����
		// �Է� �ޱ�

		cout << endl << "�÷��̾� ���ڸ� �Է��ϼ��� : ";
		cin >> inputval;
		
	}

	this->SetBingoData(inputval);
	
	return inputval;
}

int cBingo::GetEaseAIVal()
{
	int outat = -1;
	int loopcount = 0;

	int* aibingo = m_Bingo2byarr[0]; // &m_Bingo2byarr[0][0] ����

	if (false)
	{
		// ���� ��� �������� ������ ���ư��� �ִٴ°�
		while (true)
		{
			// 10������ ���ư��� ����
			int randat = rand() % 25;
			if (aibingo[randat] > 0)
			{
				cout << "���� : " << loopcount << endl;
				return aibingo[randat];
			}
			++loopcount;
		}
	}
	else
	{
		int at = 0;
		int temparr[25] = { 0, };
		for (int i = 0; i < 25; i++)
		{
			if (aibingo[i] > 0)
			{
				temparr[at++] = aibingo[i];
			}
		}

		if (at <= 0)
		{
			return -1;
		}

		int randat = rand() % at;
		return temparr[rand() % at];
	}
}


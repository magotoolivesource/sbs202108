#include "MInt.h"


MInt::MInt()
{
	
}
MInt::MInt(int p_val)
{
	m_val = p_val;
}
MInt::~MInt()
{

}

void MInt::Add(int p_val)
{
	m_val = m_val + p_val;
}
void MInt::Add(MInt p_val)
{
	m_val = m_val + p_val.m_val;
}
void MInt::Sub(int p_val)
{
	
	m_val -= p_val;
}

bool MInt::ISCompare(MInt p_val)
{
	return false;
}

bool MInt::ISCompare(int p_val)
{
	return false;
}

MInt MInt::operator+ (MInt p_val)
{
	MInt outval = *this;
	outval.m_val = this->m_val + p_val.m_val;
	return outval;
}
MInt MInt::operator+ (int p_val)
{
	MInt val = *this;
	val.m_val = this->m_val + p_val;
	return val;
}

// ����������
MInt MInt::operator++ ()
{
	// ++this->m_val;
	this->m_val += 1;
	return *this;
}

// ����������
MInt MInt::operator++ (int)
{
	MInt outval = *this;
	++this->m_val;
	return outval;
}
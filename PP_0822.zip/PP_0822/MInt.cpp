#include "MInt.h"


MInt::MInt()
{
	
}
MInt::MInt(int p_val)
{
	m_val = p_val;
}
MInt::~MInt()
{

}

void MInt::Add(int p_val)
{
	m_val = m_val + p_val;
}
void MInt::Add(MInt p_val)
{
	m_val = m_val + p_val.m_val;
}
void MInt::Sub(int p_val)
{
	
	m_val -= p_val;
}

MInt MInt::operator+ (MInt p_val)
{
	//Mint outval = *this;
	MInt outval = *this;
	outval.m_val = this->m_val + p_val.m_val;
	return outval;
}
MInt MInt::operator+ (int p_val)
{
	MInt val = *this;
	//Mint outval = *this;
	val.m_val = this->m_val + p_val;
	return val;
}

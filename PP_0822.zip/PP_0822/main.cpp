#include <iostream>
#include <stdio.h>
#include "MInt.h"

int Add(int p_src, int p_dest)
{
	return p_src + p_dest;
}

void main()
{
	printf("Hello World!!");


	int a = 10;
	int b = 20;
	int c = 30;

	a = b + c; // 50
	a = Add(b, c);


	MInt tempa(10);
	MInt tempb(20);
	MInt tempc(30);


	tempa = tempc + tempb;
	//+, -, /, %, *, =, ==, +=, -=, ++, --


	//tempa = tempb + tempc;
	tempa.Add(tempb);
	//tempa.Sub(tempb);

	tempa.Add(20); 	//tempa.m_val = 30;
	int outval = tempa.m_val;
	printf("%d", tempa.m_val);


}
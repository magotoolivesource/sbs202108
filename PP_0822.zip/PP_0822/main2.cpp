#include <iostream>
#include <stdio.h>
#include "MInt.h"
#include "Vector2.h"


int Add(int p_src, int p_dest)
{
	return p_src + p_dest;
}

int p_val2 = 0;
void TestFN()
{
	static int p_val = 0;
	++p_val;
	++p_val2;
	printf("TestFNCall : %d, %d\n", p_val, p_val2);

	
}

void main2()
{
	p_val2 = 5;
	//p_val = 3;
	TestFN();
	TestFN();



	printf("Hello World!!");


	int a = 10;
	int b = 20;
	int c = 30;

	a = b + c; // 50
	a = Add(b, c);


	MInt tempa(10);
	MInt tempb(20);
	MInt tempc(30);


	tempa = tempc + tempb;
	//+, -, /, %, *, =, ==, +=, -=, ++, --

	// ����������
	++tempc;
	// ����������
	tempc++;

	
	//const int val5 = 5;


	int val2 = 0;
	int arrval[10] = { 0, };
	arrval[val2++] = 10;
	arrval[++val2] = 20;

	printf("%d", ++val2); // ����������
	printf("%d", val2++); // ����������




	//tempa = tempb + tempc;
	tempa.Add(tempb);
	//tempa.Sub(tempb);

	tempa.Add(20); 	//tempa.m_val = 30;
	int outval = tempa.m_val;
	printf("%d", tempa.m_val);



	Vector2 tempval0(1, 2);
	Vector2 tempval1(10, 20);
	Vector2 tempval2;


	tempval2 = tempval0 + tempval1;
	//Vector2 Vector2::operator+ (Vector2 p_val)

	tempval2 = tempval0 * 2;
	tempval2 = 2 * tempval0;


	Vector2 tt = tempval2++;
	tt._x = 20;

	int xval = tt[0];
	int yval = tt[1];


	std::cout << std::endl;
	std::cout << tt << std::endl;

	std::cin >> tt;



	Vector2 testVec2;
	testVec2.Add(10);


	Vector2::Print( testVec2 );
	Vector2::p_vec._x;

	//Vector2::Add(20);
}

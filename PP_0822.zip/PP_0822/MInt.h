#pragma once
class MInt
{
public:
	MInt();
	MInt(int p_val);
	virtual ~MInt();

public:
	void Add(int p_val);
	void Add(MInt p_val);
	void Sub(int p_val);
	bool ISCompare(MInt p_val);
	bool ISCompare(int p_val);

public:
	int m_val = 0;

public:
	// +, -, /, %, *, =, +=, -=, ++, --
	// <=, >=, <, >, ==, !=
	MInt operator+ (MInt);
	MInt operator+ (int);


	MInt operator++ ();
	MInt operator++ (int);

};


#include "Student.h"
#include <stdio.h>
#include <string.h>
#include <iostream>


int Student::AllStudentCount = 0;
void Student::PrintStudentAllCount()
{
	printf("��ü�л�: %d", Student::AllStudentCount);
}

bool Student::ISCompareAge(const void* p_src, const void* p_dest)
{
	//Student* tempstd = dynamic_cast<Student*>(p_src);

	int* src = (int*)p_src;
	int* dest = (int*)p_dest;

	if ( src == dest )
	{
		return true;
	}
	return false;
}

Student::Student(const char* p_name, int p_age)
{
	//int i = 0;
	//while (p_name[i] != 0)
	//{
	//	name[i] = p_name[i];
	//	++i;
	//}

	strncpy_s(name, p_name, MAX_NAME - 1);
	age = p_age;


	++Student::AllStudentCount;
}

Student::~Student(void)
{
}

void Student::Show(void)
{
	std::cout << "�л�" <<std::endl
		<< '\t' << "�̸�:" << name << std::endl
		<< '\t' << "����:" << age << std::endl;
}

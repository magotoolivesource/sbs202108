#include "Vector2.h"
#include <stdio.h>

void Vector2::Print( const Vector2& p_src)
{
	printf("(%d, %d)", p_src._x, p_src._y);
}

inline void Vector2::Add(Vector2 p_val)
{
	_x += p_val._x;
	_y += p_val._y;

}

void Vector2::Add(int p_val)
{
}



std::ostream& operator<<(std::ostream& os
	, const Vector2 p_dest)
{
	os <<"(" << p_dest._x << ", " << p_dest._y <<")";
	return os;
}

std::istream& operator>>(std::istream& ios, Vector2& p_dest)
{
	// TODO: ���⿡ return ���� �����մϴ�.
	ios >> p_dest._x;
	ios >> p_dest._y;
	return ios;
}

int Vector2::operator[](int p_index)
{
	if (p_index == 0)
		return _x;

	return _y;
}

Vector2 Vector2::operator++()
{
	++_x, ++_y;
	return *this;
}

const Vector2& Vector2::operator++(int)
{
	const Vector2 temp = *this;
	++*this;
	//temp._x = 20;
	return temp;
}

Vector2 Vector2::operator+ ( Vector2& p_val ) const
{
	Vector2 outval;
	////this->_x = 10;
	//this->_x = 20;
	//p_val->_x = 30;

	outval._x = this->_x + p_val._x;
	outval._y = this->_y + p_val._y;
	return outval;
}
Vector2 Vector2::operator+ (int p_val) const
{
	Vector2 outval;
	outval._x = _x + p_val;
	outval._y = _y + p_val;
	return outval;
}
Vector2 Vector2::operator* (int p_val) const
{
	Vector2 outval;
	outval._x = _x * p_val;
	outval._y = _y * p_val;
	return outval;
}
Vector2 operator* (int p_val, const Vector2& p_val2)
{
	Vector2 outval;
	outval._x = p_val2._x * p_val;
	outval._y = p_val2._y * p_val;
	return outval;
}

Vector2 operator* (float p_val, const Vector2& p_val2)
{
	Vector2 outval;
	outval._x = p_val2._x * p_val;
	outval._y = p_val2._y * p_val;
	return outval;
}

Vector2 Vector2::operator/ (int p_val) const
{
	if (p_val == 0)
	{
		return *this;
	}

	Vector2 outval;
	outval._x = _x + p_val;
	outval._y = _y + p_val;
	return outval;
}
bool Vector2::operator==(Vector2 p_val)const
{
	if (_x == p_val._x && _y == p_val._y)
		return true;
	return false;
}

bool Vector2::operator!=( Vector2 p_val)const
{
	if (_x == p_val._x && _y == p_val._y)
		return false;

	return true;
}

bool Vector2::operator>=(Vector2 p_val) const
{
	if (this->_x >= p_val._x
		&& this->_y >= p_val._y )
		return true;

	return false;
}

#pragma once
class Vector2
{
public:
	int _x;
	int _y;


public:
	void Add();
	void Sub();

};


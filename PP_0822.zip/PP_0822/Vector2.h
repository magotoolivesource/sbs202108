#pragma once
#include <iostream>

class Vector2
{
public:
	static void Print(const Vector2& p_src);
	static Vector2 p_vec;

public:
	Vector2()
	{
		_x = 0;
		_y = 0;
	}
	Vector2(int p_all) : _x(p_all), _y(p_all)
	{
	}
	Vector2(int p_x, int p_y) : _x(p_x), _y(p_y)
	{
	}

public:
	int _x = 0;
	int _y = 0;


public:
	void Add(Vector2 p_val); // _x + p_val._x, _y + p_val._y
	void Add(int p_val); // _x + p_val, _y + p_val
	void Sub();
	void Multi(int p_val); // _x * p_val._x, _y * p_val._y

public:
	int operator[] (int p_index);

	Vector2 operator++ ();
	const Vector2& operator++ (int);

	Vector2 operator+ (Vector2& p_val) const;
	Vector2 operator+ (int p_val) const;
	Vector2 operator* (int p_val) const;
	friend Vector2 operator* (int p_val, const Vector2& p_val2);
	friend Vector2 operator* (float p_val, const Vector2& p_val2);
	Vector2 operator/ (int p_val) const;
	bool operator==(Vector2 p_val) const;
	bool operator!=(Vector2 p_val) const;
	bool operator>=(Vector2 p_val) const;


	friend std::ostream& operator<<( std::ostream& os
		, const Vector2 p_dest );


	friend std::istream& operator>>(std::istream& os, Vector2& p_dest);
	
	//bool operator<=(Vector2 p_val);
	//bool operator<(Vector2 p_val);
	//bool operator>(Vector2 p_val);


};


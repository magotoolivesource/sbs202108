#include <iostream>
#include "Array.h"


void main()
{

	Array arraydata;

	arraydata.Push(10);
	arraydata.Push(20);
	arraydata.Push(40);
	//int tempval = arraydata.Pop();


	arraydata.Print();

}
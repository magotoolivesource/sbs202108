#include <iostream>
#include <cassert>
#include "Array.h"
#include "TArray.h"
#include <vector>
#include <map>

//#include "TArray.cpp"

void main()
{




	//std::vector<int> tempvec;
	//std::map<int, int> tempmap;
	//std::multimap<int, int> tempmultimap;
	//std::queue;
	//std::stack;


	//tempvec.push_back(10);
	//tempvec.push_back(20);
	//tempvec.push_back(50);
	//tempvec.push_back(80);
	//tempvec.push_back(1);
	//int tempval000 = tempvec[0];




	//assert(0);

	Array arraydata;

	arraydata.Push(0);
	arraydata.Push(20);
	arraydata.Push(40);
	int tempval2 = arraydata.GetAT(2);
	//tempval2 = arraydata.GetAT(4); // ���� ���� �κ� Ȯ�ο�

	int tempval = arraydata.Pop();

	arraydata.Print();


	int aa = 10;
	auto bb = 20;
	auto cc = 20.0f;
	auto dd = "abc";




	TArray<float> temparr;

	temparr.Push(1.1f);
	temparr.Push(3.3f);
	temparr.Push(4.6f);
	temparr.Push(7.3f);

	float tempfval = temparr.GetAT(1);
	float tempfval2 = temparr[2];

	temparr.Remove(2);
	temparr.Remove(2);

	// �ε��Ҽ��� ���� ����
	if (tempfval2 == 4.6f)
	{
		int intempval = 0;
	}

	temparr.Print();


}
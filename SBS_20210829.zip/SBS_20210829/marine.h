#pragma once

enum E_ACTORTYPE
{
	Bio,
	Mechine,
	
};

enum E_BIONIC
{
	E_Marin,
	E_Medic,


};

class BaseActor
{
protected:
	int HP;
	float AttackVal;
	float DefVal;
	float PosX;
	float PosY;
	float MoveSpeed;
	float AttackRange;

	E_ACTORTYPE m_Type;

public:
	virtual void Attack();// = 0; // �������̽� ���
	virtual void Move();
	void Stop();

	void SetDamage(int p_val);

};




class Protos : BaseActor
{

};

class Zellet : Protos
{

};

class Teran : BaseActor
{

};



class TerrinaBionic : public Teran
{

};

class Medic : TerrinaBionic
{
	virtual void Attack()
	{
		// �츮���� �����ϱ�
	}
};

class marine : TerrinaBionic
{


};

class Filebat : TerrinaBionic
{
	float Range = 1.0f;
	virtual void Attack()
	{

	}
};


class Mechine : public Teran
{

};

class vulture : public  Mechine
{


	void Mine();

};

class Tank : public  Mechine
{
	
	bool m_ISSigeMode = false;
	void SigeMode()
	{
		if (m_ISSigeMode)
		{
			AttackRange = 100.0f;
		}
		else
		{
			AttackRange = 60;
		}

	}
};


class Scout : public Mechine
{
	virtual void Move()
	{

	}

};


class Mine : BaseActor
{
	virtual void Move()
	{
		;
	}
};



class Barrack : Teran
{
	public TerrinaBionic arr[4] = { Medic(), };

	TerrinaBionic CreateActor(E_BIONIC p_type)
	{
		return arr[(int)p_type];
	}

};

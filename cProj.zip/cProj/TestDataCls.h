#pragma once

class TestDataCls
{
public:
	TestDataCls();
	TestDataCls(int p_size);
	~TestDataCls();

public:
	int* p_intdata = nullptr; // nullptr c++Ű����

};


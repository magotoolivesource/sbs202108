//#include <stdio.h>
#include <iostream>
#include "PointCls.h"
// ../ ������������
//#include "../../TestCPP/PointCls.h"


//using std::cout;
using namespace std;


// ������
PointCls::PointCls() :
	y(0) // ������ �ʱ�ȭ
{
	x = 0; // ������ �ʱ�ȭ
}
PointCls::PointCls(int p_x, int p_y) : y(p_y)
{
	x = p_x;
}

// �Ҹ���
PointCls::~PointCls()
{
	cout << "�Ҹ���ȣ��� " << x << ", " << y << endl;
}

void PointCls::SetPos(int p_x, int p_y)
{
	this->x = p_x;
	y = p_y;
}

void PointCls::SetMove(int p_x, int p_y)
{
	x += p_x;
	this->y += p_y;
}

void PointCls::Show()
{
	printf("(%d, %d)\n", this->x, this->y);

	std::cout << "(" << x << "," << y << ")" << std::endl;
}

float PointCls::GetLength()
{
	return sqrt(x * x + y * y);
}
float PointCls::GetLength(const PointCls* const p_src)
{
	int tempx = p_src->x - this->x;
	int tempy = p_src->y - this->y;

	return sqrt(pow(tempx, 2) + pow(tempy, 2));
}

float PointCls::GetLength(const PointCls& p_src)
{
	int tempx = p_src.x - this->x;
	int tempy = p_src.y - this->y;

	return sqrt(pow(tempx, 2) + pow(tempy, 2));
}

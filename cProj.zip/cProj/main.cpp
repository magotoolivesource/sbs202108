#include <stdio.h>
#include <iostream>
#include "PointCls.h"
#include "TestDataCls.h"

PointCls g_p3(5, 7);
void main()
{
	TestDataCls ttcls(10);
	TestDataCls* ttcls2 = new TestDataCls();


	delete ttcls2;
	ttcls2 = nullptr;


	PointCls p1, p2;
	PointCls p3(2, 3);

	p3.Show();
	p1.SetPos(20, 20);
	p2.SetPos(10, 20);

	float length = p1.GetLength(p2);

	std::cout << "���̰� " << length << std::endl;

}

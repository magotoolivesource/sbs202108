#include <stdio.h>

struct Point
{
	int x, y;
};

void SetPosition(struct Point* pPoint, int _x, int _y)
{
	pPoint->x = _x;
	pPoint->y = _y;
}

void Move(struct Point* pPoint, int _x, int _y)
{
	pPoint->x += _x;
	pPoint->y += _y;
}

void Show(const struct Point* pPoint)
{
	printf("(%d, %d)\n", pPoint->x, pPoint->y);
}

int main2(void)
{
	struct Point p1, p2;

	SetPosition(&p1, 10, 20); // x = 10, y = 20
	SetPosition(&p2, 50, 60); // x = 50, y = 60

	Move(&p1, 5, 0); // x = 15, y = 20
	Move(&p2, 0, 5); // x = 50, y = 65

	Show(&p1);
	Show(&p2);

	return 0;
}




//#include <stdio.h>
//
//char g_char;
//
//void TestCallFN2(char* p_msg);
//void TestCallFN(char* p_msg);
//
//
//void main()
//{
//	int result = 10;
//
//	bool isflag;
//
//
//}
//
//
//
//
//
//void TestCallFN2()
//{
//	g_char = 2;
//	TestCallFN();
//}
//
//void TestCallFN(char* p_msg)
//{
//	TestCallFN2();
//}
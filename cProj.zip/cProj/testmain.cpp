#include <iostream>
#include <stdio.h>



void Move(int _x, int _y);

struct Point2
{
	int x, y;

	void SetPosition(int _x, int _y)
	{
		x = _x;
		y = _y;
	}
	void Move(int _x, int _y);
	void Show(void);
};

void ::Move(int _x, int _y)
{

}

void Point2::Move(int _x, int _y)
{
	x += _x;
	y += _y;
}

void Point2::Show(void)
{
	//printf("(%d, %d)");
	std::cout << x << ", " << y << std::endl;
}

void main(void)
{
	Point2 p1, p2;

	p1.SetPosition(10, 20);
	p1.Show();


	p2.Show();
}








//#include <stdio.h>
//
//
//int g_tempval = 20;
//
//// ����� ----------------------
//void swap(int* a, int* b);
//void swap2(int& a, int& b);
//
//
//// ���� ----------------------
//int main(void)
//{
//
//	//int* tempval = (int*)malloc(sizeof(int) * 10);
//	int* tempval2 = new int;
//
//	delete tempval2;
//	tempval2 = nullptr;
//
//
//	int* tempval3 = new int[10];
//	delete []tempval3;
//
//
//
//
//	int a = 10, b = 20;
//	swap(&a, &b);
//	swap2(a, b);
//	printf("a=%d\n", a);
//	printf("b=%d\n", b);
//	return 0;
//}
//
//void swap2(int& a, int& b)
//{
//	a++; // 11
//}
//
//// ������ ----------------------
//void swap(int* a, int* b)
//{
//	a[0] = 10;
//	a[1] = 11;
//	a++; // 10 -> 11
//	a[0];
//	a[1];
//
//	int temp;
//	temp = *a;
//	*a = *b;
//	*b = temp;
//
//	
//}

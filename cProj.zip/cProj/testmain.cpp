//#include <iostream>
//#include <stdio.h>
//
//struct Point2
//{
//	int x, y;
//
//	void SetPosition(int _x, int _y)
//	{
//		x = _x;
//		y = _y;
//	}
//	void Move(int _x, int _y);
//	void Show(void);
//
//	// ���̰� ���ϱ�
//	double Getlength();
//	double Getlength(Point2 p_src); // �����ε� ���
//
//};
//
//double Point2::Getlength(Point2 p_src)
//{
//	int tempx = p_src.x - x;
//	int tempy = p_src.y - y;
//
//	double xypow = (pow(tempx, 2) + pow(tempy, 2));
//	return sqrt(xypow);
//}
//double Point2::Getlength()
//{
//	// +, -, /, *, sqrt(root), pow(������), sin(), cos(), tan(), %, dot(), cross(),
//	double outval = sqrt(x * x + y * y);
//	return outval;
//}
//
//void Point2::Move(int _x, int _y)
//{
//	x += _x;
//	y += _y;
//}
//
//void Point2::Show(void)
//{
//	//printf("(%d, %d)");
//	std::cout << x << ", " << y << std::endl;
//}
//
//
//
//class Point_Cls
//{
//public:
//	void SetPosition(int _x, int _y);
//	void Move(int _x, int _y);
//	void Show(void);
//
//	// ���̰� ���ϱ�
//	double Getlength();
//	double Getlength(Point2 p_src); // �����ε� ���
//
//private:
//	int x2, y2;
//
//public:
//public:
//	int x, y;
//};
//
//void Point_Cls::SetPosition(int x, int y)
//{
//	this->x = x;
//	this->y = y;
//	//this->x
//}
//
//
//
//void main(void)
//{
//
//	Point_Cls clsp1;
//	clsp1.x2 = 20;
//
//
//	//float result = 8 / 2 * (2 + 2);
//
//
//	Point2 p1, p2;
//
//	p2.SetPosition(20, 10);
//	p1.SetPosition(20, 20);
//	p1.Show();
//
//	double length = p1.Getlength(p2);
//	std::cout << "���̰� : " << length << std::endl;
//	printf("%f\n", length);
//
//	p2.Show();
//}
//
//
//
//
//
//
//
//
////#include <stdio.h>
////
////
////int g_tempval = 20;
////
////// ����� ----------------------
////void swap(int* a, int* b);
////void swap2(int& a, int& b);
////
////
////// ���� ----------------------
////int main(void)
////{
////
////	//int* tempval = (int*)malloc(sizeof(int) * 10);
////	int* tempval2 = new int;
////
////	delete tempval2;
////	tempval2 = nullptr;
////
////
////	int* tempval3 = new int[10];
////	delete []tempval3;
////
////
////
////
////	int a = 10, b = 20;
////	swap(&a, &b);
////	swap2(a, b);
////	printf("a=%d\n", a);
////	printf("b=%d\n", b);
////	return 0;
////}
////
////void swap2(int& a, int& b)
////{
////	a++; // 11
////}
////
////// ������ ----------------------
////void swap(int* a, int* b)
////{
////	a[0] = 10;
////	a[1] = 11;
////	a++; // 10 -> 11
////	a[0];
////	a[1];
////
////	int temp;
////	temp = *a;
////	*a = *b;
////	*b = temp;
////
////	
////}

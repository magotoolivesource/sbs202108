#include "TestDataCls.h"



TestDataCls::TestDataCls()
{
	p_intdata = nullptr;
}
TestDataCls::TestDataCls(int p_size)
{
	p_intdata = new int[p_size];
}
TestDataCls::~TestDataCls()
{
	if (p_intdata != nullptr)
	{
		delete[] p_intdata;
		p_intdata = nullptr;
	}
	
}
// 


#include <stdio.h>
#include <Windows.h>


// �����Լ�
void main()
{
	// ������Ʈ ���� ������Դϴ�.

	//int val1 = 1;
	//int val2 = 2;
	//int val3 = 3;

	//// int,long -> %d
	//// char[] -> %s
	//// char -> %c
	//// float, double -> %f


	//printf("%d ", val1);
	//printf("%d ", val2);
	//printf("%d ", val3);

	//int val1 = 1;
	//int val2 = 2;
	//int val3 = 3;



	// 3x3 
	int by2arr[3][3] = {
			 { 1, 2, 3}
			,{ 4, 5, 6}
			,{ 7, 9, 8}
	};


	COORD cursourpos;
	cursourpos.X = 0;
	cursourpos.Y = 0;
	for (int y = 0; y < 3; y++)
	{
		for (int x = 0; x < 3; x++)
		{
			cursourpos.X = x * 2;
			cursourpos.Y = y * 2;
			SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE)
				, cursourpos);
			printf("%d", by2arr[y][x]);
		}
		//printf("\n");
	}
	
	printf("\n==========================\n");




	// 1 2 3
	int val[3] = {1, 2, 3};
	for (int i = 0; i < 3; i++)
	{
		printf("%d ", val[i] );
	}

	//printf("\n");

	

	// 4 5 6
	int val2[3] = { 4, 5, 6 };
	for (int i = 0; i < 3; i++)
	{
		printf("%d ", val2[i]);
	}

	printf("\n==========================\n");


	//printf("%d %d %d", val1, val2, val3 );



	//printf("4 5 6");


}

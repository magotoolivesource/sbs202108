#include "Bear.h"


void G_Move()
{

}

void Bear::Cramp()
{
	this->MoveSpeed = 5;

	this->Move();
}
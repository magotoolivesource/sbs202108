#include "Animal.h"


void G_Move();

void Animal::Move()
{
	::G_Move();
}

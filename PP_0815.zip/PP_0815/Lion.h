#pragma once
#include "Animal.h"

// ����
class Lion : public Animal
{
//public:
//	int HP = 10;
//	float MoveSpeed = 20; // 20Ű�� �̵�
//
//public:
//	void Move();
//	void Run();
//	void Attack();

public:
	void GroupAttack();

};


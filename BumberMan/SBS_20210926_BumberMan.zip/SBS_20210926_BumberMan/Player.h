#pragma once
#include "MPoint.h"

class Player
{
public:
	Player();
	virtual ~Player();

protected:
	MPOINT m_Pos;
	MPOINT m_StageSize;
	MPOINT* m_pStageSize = nullptr;

public:
	void Init(const MPOINT* const p_startpos, MPOINT* const p_stagesize);
	void AddMove(int p_x, int p_y);


public:
	void PrintPlayer();

};


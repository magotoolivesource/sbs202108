﻿// SBS_20210926_BumberMan.cpp : 이 파일에는 'main' 함수가 포함됩니다. 거기서 프로그램 실행이 시작되고 종료됩니다.
//

#include "pch.h"
#include <iostream>
//#include <cstdlib> // c stdlib.h
#include <conio.h> // getch 함수 사용하기 위한 헤더

using namespace std;


// https://stackoverflow.com/questions/10463201/getch-and-arrow-codes
//Left E0 4B
//Right E0 4D
//Up E0 48
//Down E0 50
#define SAFEDELETE(x) if(x != NULL) {delete x; x= NULL;}
#define RIGHTARROW 77
#define LEFTARROW 75
#define UPARROW 72
#define DOWNARROW 80

#define GRIDMAPSIZEX 20 
#define GRIDMAPSIZEY 10

// 플레이어 자료
//struct PlayerInfoData
//{
//    int X;
//    int Y;
//};
//typedef PlayerInfoData* PPlayerInfOData;
typedef struct PlayerInfoData
{
    int X;
    int Y;

    void Init()
    {
        X = 0;
        Y = 0;
    }
}PlayerData, *PPlayerData;



/// <summary>
/// 자료들
/// </summary>
PPlayerData g_pPlayerdata = NULL;



/// <summary>
/// 전방선언
/// </summary>
void PrintMage();









/// <summary>
/// 메인함수
/// </summary>
/// <returns></returns>
int main()
{
    g_pPlayerdata = new PlayerInfoData();
    g_pPlayerdata->Init();

    while (true)
    {
        system("cls");
        PrintMage();

        int keypressinfo = _getch();
        // 키보드 오른쪽 키를 눌렀을때
        //g_pPlayerdata->X += 1;


        if (keypressinfo == 224)
        {
            keypressinfo = _getch();
        }

        if (keypressinfo == RIGHTARROW
            || keypressinfo == 'd')
        {
            g_pPlayerdata->X += 1;
            if (g_pPlayerdata->X >= GRIDMAPSIZEX - 2) g_pPlayerdata->X = GRIDMAPSIZEX - 2;
        }
        else if (keypressinfo == LEFTARROW
            || keypressinfo == 'a')
        {
            g_pPlayerdata->X -= 1;
            if (g_pPlayerdata->X < 0) g_pPlayerdata->X = 0;
        }
        else if (keypressinfo == UPARROW
            || keypressinfo == 'w')
        {
            g_pPlayerdata->Y -= 1;
            if (g_pPlayerdata->Y < 0) g_pPlayerdata->Y = 0;
        }
        else if (keypressinfo == DOWNARROW
            || keypressinfo == 's')
        {
            g_pPlayerdata->Y += 1;
            if (g_pPlayerdata->Y >= GRIDMAPSIZEY - 1) g_pPlayerdata->Y = GRIDMAPSIZEY - 1;
        }

        //if (keypressinfo == 224) // 특수키보드 눌렀을때 
        //{
        //    keypressinfo = _getch();

        //    switch (keypressinfo)
        //    {
        //    case RIGHTARROW:

        //        break;
        //    case LEFTARROW:

        //        break;
        //    case UPARROW:

        //        break;
        //    case DOWNARROW:

        //        break;
        //    default:
        //        break;
        //    }

        //}

        
    }
    


    //pPlayerdata = NULL; // 스마트 포인터 기법
    SAFEDELETE(g_pPlayerdata);
    
}

/// <summary>
/// 맵 그리기
/// </summary>
void PrintMage()
{
    //cout << "S#############" << endl;
    //cout << "  @   ########" << endl;
    //cout << "##### ########" << endl;
    //cout << "##### ########" << endl;
    //cout << "##### ########" << endl;
    //cout << "##### ########" << endl;
    //cout << "#####   ######" << endl;
    //cout << "#######    &##" << endl;
    char MageInfo[10][20] = { 
          "s 11111111111111111" 
        , "1      1111     111"
        , "111111 1111 1111111"
        , "111111      1111111"
        , "111111 111111111111"
        , "111111 111111111111"
        , "111111 111111111111"
        , "111111        11111"
        , "111111 111111 11111"
        , "1111111111111   e11"
    };


    // 2차원 배열을 통한 화면 출력
    for (int y = 0; y < 10; y++)
    {
        for (int x = 0; x < 20; x++)
        {
            if ( x == g_pPlayerdata->X && y == g_pPlayerdata->Y )
            {
                //@ <- 1byte
                cout << "＠"; // 2byte
            }
            else if (MageInfo[y][x] == '1')
            {
                cout << "■"; // 2byte
            }
            else if (MageInfo[y][x] == ' ')
            {
                cout << "  "; // 2byte
            }
            else if (MageInfo[y][x] == 's')
            {
                cout << "◐"; // 2byte
            }
            else if (MageInfo[y][x] == 'e')
            {
                cout << "◑"; // 2byte
            }
            else
            {
                cout << MageInfo[y][x];
            }
        }
        cout << endl;// "\n";
    }
    
}



// 프로그램 실행: <Ctrl+F5> 또는 [디버그] > [디버깅하지 않고 시작] 메뉴
// 프로그램 디버그: <F5> 키 또는 [디버그] > [디버깅 시작] 메뉴

// 시작을 위한 팁: 
//   1. [솔루션 탐색기] 창을 사용하여 파일을 추가/관리합니다.
//   2. [팀 탐색기] 창을 사용하여 소스 제어에 연결합니다.
//   3. [출력] 창을 사용하여 빌드 출력 및 기타 메시지를 확인합니다.
//   4. [오류 목록] 창을 사용하여 오류를 봅니다.
//   5. [프로젝트] > [새 항목 추가]로 이동하여 새 코드 파일을 만들거나, [프로젝트] > [기존 항목 추가]로 이동하여 기존 코드 파일을 프로젝트에 추가합니다.
//   6. 나중에 이 프로젝트를 다시 열려면 [파일] > [열기] > [프로젝트]로 이동하고 .sln 파일을 선택합니다.

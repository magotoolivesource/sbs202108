﻿// SBS_20210926_BumberMan.cpp : 이 파일에는 'main' 함수가 포함됩니다. 거기서 프로그램 실행이 시작되고 종료됩니다.
//

#include "pch.h"
#include <iostream>
//#include <cstdlib> // c stdlib.h
#include <conio.h> // getch 함수 사용하기 위한 헤더

using namespace std;


// https://stackoverflow.com/questions/10463201/getch-and-arrow-codes
//Left E0 4B
//Right E0 4D
//Up E0 48
//Down E0 50
#define SAFEDELETE(x) if(x != NULL) {delete x; x= NULL;}
#define RIGHTARROW 77
#define LEFTARROW 75
#define UPARROW 72
#define DOWNARROW 80
#define SPACEKEY 32

#define GRIDMAPSIZEX 20 
#define GRIDMAPSIZEY 10

// 플레이어 자료
//struct PlayerInfoData
//{
//    int X;
//    int Y;
//};
//typedef PlayerInfoData* PPlayerInfOData;

typedef struct VECTOR2
{
    int x, y;
}POINT, *PPOINT;

typedef struct PlayerInfoData
{
    int X;
    int Y;

    void Init()
    {
        X = 0;
        Y = 0;
    }
}PlayerData, *PPlayerData;



/// <summary>
/// 자료들
/// </summary>
PPlayerData g_pPlayerdata = NULL;
int g_BoomCount = 5;


/// <summary>
/// 전방선언
/// </summary>
void PrintMage(char (*)[GRIDMAPSIZEX]); // void PrintMage(char* p_mage[]);
void MovePlayer(int); // void MovePlayer(int p_val);
bool MoveMage(char* p_mageinfo, PPOINT p_pos, int p_key ); // p_pos 위치에 벽이 있으면 true, false를 반환하려고함
void SetBoom(char(*)[GRIDMAPSIZEX], PPOINT p_pos);
void SetBoomFire(char(*p_mage)[GRIDMAPSIZEX]);
void SetRoundFire(char(*p_mage)[GRIDMAPSIZEX], PPOINT p_centerpos, int p_power);


/// <summary>
/// 메인함수
/// </summary>
/// <returns></returns>
int main()
{
    //POINT startpos = { 0,0 };
    //POINT endpos = { 9, 18 };
    char MageInfo[10][20] = {
          "S 11111111111111111"
        , "1      1111     111"
        , "111111 1111 1111111"
        , "111111      1111111"
        , "111111 111111111111"
        , "111111 111111111111"
        , "111111 111111111111"
        , "111111        11111"
        , "111111 111111 11111"
        , "1111111111111   E11"
    };

    /*MageInfo[0][0] = 'a';
    char* temppos = &MageInfo[0][0];*/



    g_pPlayerdata = new PlayerInfoData();
    g_pPlayerdata->Init();

    POINT playerpos;
    
    while (true) 
    {
        system("cls");
        PrintMage(MageInfo);

        // 키보드 키를 누루기 전까지 멈추게됨
        int keypressinfo = _getch();

        // 화살표 키를 눌렀을때 사용하기 위한 값들
        if (keypressinfo == 224)
        {
            keypressinfo = _getch();
        }

        playerpos.x = g_pPlayerdata->X;
        playerpos.y = g_pPlayerdata->Y;

        if (SPACEKEY == keypressinfo )
        {
            SetBoom( MageInfo , &playerpos);
        }
        if ( 'f' == keypressinfo)
        {
            SetBoomFire(MageInfo);
        }

        bool ismove = MoveMage( &MageInfo[0][0], &playerpos, keypressinfo );
        if ( ismove )
        {
            MovePlayer(keypressinfo);
        }
    }
    

    //pPlayerdata = NULL; // 스마트 포인터 기법
    SAFEDELETE(g_pPlayerdata);
    
}

void SetRoundFire(char(*p_mage)[GRIDMAPSIZEX], PPOINT p_centerpos, int p_power)
{
    int tempx = p_centerpos->x;
    int tempy = p_centerpos->y;
    // 오른쪽
    if (tempx + p_power < GRIDMAPSIZEX - 1 )
    {
        if(p_mage[tempy][tempx + p_power] == '1')
            p_mage[tempy][tempx + p_power] = ' ';
    }
    
    // 왼쪽
    if (tempx - p_power >= 0)
    {
        if (p_mage[tempy][tempx - p_power] == '1')
            p_mage[tempy][tempx - p_power] = ' ';
    }

    // 상단
    if (tempy - p_power >= 0)
    {
        if (p_mage[tempy - p_power][tempx] == '1')
            p_mage[tempy - p_power][tempx] = ' ';
    }

    // 하단
    if (tempy + p_power < GRIDMAPSIZEY)
    {
        if(p_mage[tempy + p_power][tempx] == '1')
            p_mage[tempy + p_power][tempx] = ' ';
    }

}

void SetBoomFire(char(*p_mage)[GRIDMAPSIZEX])
{
    g_BoomCount = 5;

    for (int y = 0; y < GRIDMAPSIZEY; y++)
    {
        for (int x = 0; x < GRIDMAPSIZEX; x++)
        {
            if ( p_mage[y][x] == '2'
                || p_mage[y][x] >= 'E' + 20 )
            {
                if (p_mage[y][x] >= 'E' + 20)
                {
                    p_mage[y][x] -= 20;
                }
                else
                {
                    p_mage[y][x] = ' ';
                }
                //  
                POINT centerpos = { x, y };
                SetRoundFire( p_mage, &centerpos, 1);

                /*if ( y + 1 < GRIDMAPSIZEY 
                    && y - 1 >= 0)
                {
                    p_mage[y + 1][x] = ' ';
                    p_mage[y - 1][x] = ' ';
                }
                
                if (x + 1 < GRIDMAPSIZEX
                    && x - 1 >= 0)
                {
                    p_mage[y][x + 1] = ' ';
                    p_mage[y][x - 1] = ' ';
                }*/
            }
        }
    }

}

void SetBoom(char(*p_mage)[GRIDMAPSIZEX], PPOINT p_pos)
{
    if (g_BoomCount <= 0)
        return;

    --g_BoomCount;
    if (p_mage[p_pos->y][p_pos->x] == 'S'
        || p_mage[p_pos->y][p_pos->x] == 'E')
    {
        p_mage[p_pos->y][p_pos->x] += 20; // 폭탄
    }
    else
    {
        p_mage[p_pos->y][p_pos->x] = '2'; // 폭탄
    }
    
}

/// <summary>
/// 미로정보를 이용한 이동 가능 여부
/// </summary>
/// <param name="p_mageinfo"> 미로정보 2차원 -> 1차원 </param>
/// <param name="p_pos">현재위치</param>
/// <param name="p_key">이동할 키값</param>
/// <returns>이동이면 ture </returns>
bool MoveMage(char* p_mageinfo, PPOINT p_pos, int p_key)
{
    // 2차원에 값을 1차원으로 사용
    if (p_key == RIGHTARROW
        || p_key == 'd')
    {
        p_pos->x += 1;
    }
    else if (p_key == LEFTARROW
        || p_key == 'a')
    {
        p_pos->x -= 1;
    }
    else if (p_key == UPARROW
        || p_key == 'w')
    {
        p_pos->y -= 1;
        
    }
    else if (p_key == DOWNARROW
        || p_key == 's')
    {
        p_pos->y += 1;
    }

    if ( p_mageinfo[(p_pos->y * GRIDMAPSIZEX) + p_pos->x] == '1'
        || p_mageinfo[(p_pos->y * GRIDMAPSIZEX) + p_pos->x] == '2'
        )
    {
        return false;
    }
    
    return true;
}

void MovePlayer( int p_key )
{
    if (p_key == RIGHTARROW
        || p_key == 'd')
    {
        g_pPlayerdata->X += 1;
        if (g_pPlayerdata->X >= GRIDMAPSIZEX - 2) g_pPlayerdata->X = GRIDMAPSIZEX - 2;
    }
    else if (p_key == LEFTARROW
        || p_key == 'a')
    {
        g_pPlayerdata->X -= 1;
        if (g_pPlayerdata->X < 0) g_pPlayerdata->X = 0;
    }
    else if (p_key == UPARROW
        || p_key == 'w')
    {
        g_pPlayerdata->Y -= 1;
        if (g_pPlayerdata->Y < 0) g_pPlayerdata->Y = 0;
    }
    else if (p_key == DOWNARROW
        || p_key == 's')
    {
        g_pPlayerdata->Y += 1;
        if (g_pPlayerdata->Y >= GRIDMAPSIZEY - 1) g_pPlayerdata->Y = GRIDMAPSIZEY - 1;
    }
}

/// <summary>
/// 맵 그리기
/// </summary>
void PrintMage( char (*p_mageinfo)[20] )
{
    //cout << "S#############" << endl;
    //cout << "  @   ########" << endl;
    //cout << "##### ########" << endl;
    //cout << "##### ########" << endl;
    //cout << "##### ########" << endl;
    //cout << "##### ########" << endl;
    //cout << "#####   ######" << endl;
    //cout << "#######    &##" << endl;


    //p_mageinfo[0][0] = 'a';


    // 2차원 배열을 통한 화면 출력
    for (int y = 0; y < 10; y++)
    {
        for (int x = 0; x < 20; x++)
        {
            if ( x == g_pPlayerdata->X && y == g_pPlayerdata->Y )
            {
                //@ <- 1byte
                cout << "＠"; // 2byte
            }
            else if (p_mageinfo[y][x] == '1')
            {
                cout << "■"; // 2byte
            }
            else if (p_mageinfo[y][x] == '2'
                || p_mageinfo[y][x] == 'S' + 20
                || p_mageinfo[y][x] == 'E' + 20
                )
            {
                // 폭탄
                cout << "♨"; // 2byte
            }
            else if (p_mageinfo[y][x] == ' ')
            {
                cout << "  "; // 2byte
            }
            else if (p_mageinfo[y][x] == 'S')
            {
                cout << "◐"; // 2byte
            }
            else if (p_mageinfo[y][x] == 'E')
            {
                cout << "◑"; // 2byte
            }
            else
            {
                cout << p_mageinfo[y][x];
            }
        }
        cout << endl;// "\n";
    }
    
    // 폭탄 갯수 정보
    cout << endl << endl;

    cout << "총폭탄 갯수 : " << g_BoomCount;

}



// 프로그램 실행: <Ctrl+F5> 또는 [디버그] > [디버깅하지 않고 시작] 메뉴
// 프로그램 디버그: <F5> 키 또는 [디버그] > [디버깅 시작] 메뉴

// 시작을 위한 팁: 
//   1. [솔루션 탐색기] 창을 사용하여 파일을 추가/관리합니다.
//   2. [팀 탐색기] 창을 사용하여 소스 제어에 연결합니다.
//   3. [출력] 창을 사용하여 빌드 출력 및 기타 메시지를 확인합니다.
//   4. [오류 목록] 창을 사용하여 오류를 봅니다.
//   5. [프로젝트] > [새 항목 추가]로 이동하여 새 코드 파일을 만들거나, [프로젝트] > [기존 항목 추가]로 이동하여 기존 코드 파일을 프로젝트에 추가합니다.
//   6. 나중에 이 프로젝트를 다시 열려면 [파일] > [열기] > [프로젝트]로 이동하고 .sln 파일을 선택합니다.

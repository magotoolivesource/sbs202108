﻿// SBS_20210926_BumberMan.cpp : 이 파일에는 'main' 함수가 포함됩니다. 거기서 프로그램 실행이 시작되고 종료됩니다.
//


// 다음 시간 작업할것들
// push 방식과 class화 하기



#include "pch.h"
#include <iostream>
//#include <cstdlib> // c stdlib.h
#include <conio.h> // getch 함수 사용하기 위한 헤더
//#include <Windows.h>
#include <cassert> // c assert.h

using namespace std;


// https://stackoverflow.com/questions/10463201/getch-and-arrow-codes
//Left E0 4B
//Right E0 4D
//Up E0 48
//Down E0 50
#define SAFEDELETE(x) if(x != NULL) {delete x; x= NULL;}
#define RIGHTARROW 77
#define LEFTARROW 75
#define UPARROW 72
#define DOWNARROW 80
#define SPACEKEY 32

#define GRIDMAPSIZEX 20 
#define GRIDMAPSIZEY 10

// 값 설정
#define WALL '1'
#define ROAD ' '
#define BOOM '2'
#define SBOOM 'S' + 20
#define EBOOM 'E' + 20

#define BOOMITEM '5'
#define BOOMPOWER '6'
#define WALLPUSH '7'
#define WALLGHOST '8'
#define WALLTRHOW '9'


#define MAXBOOMPOWER 3

// 플레이어 자료
//struct PlayerInfoData
//{
//    int X;
//    int Y;
//};
//typedef PlayerInfoData* PPlayerInfOData;

typedef struct VECTOR2
{
    int x, y;
}POINT, *PPOINT;

typedef struct PlayerInfoData
{
    int X;
    int Y;
    int Power;
    bool Ghost;
    bool MoveGhost;
    bool WallPush; // 사용하지 않을것임
    bool WallThrow;

    int LifeCount;

    void Init()
    {
        X = 0;
        Y = 0;
        Power = 1;
        Ghost = false;
        MoveGhost = false;
        WallPush = false;
        WallThrow = false;
        LifeCount = 3;
    }

}PlayerData, *PPlayerData;



/// <summary>
/// 자료들
/// </summary>
PPlayerData g_pPlayerdata = NULL;
int g_BoomCount = 5;


/// <summary>
/// 전방선언
/// </summary>
void PrintMage(char (*)[GRIDMAPSIZEX]); // void PrintMage(char* p_mage[]);
void MovePlayer(int, char(*)[GRIDMAPSIZEX]); // void MovePlayer(int p_val);
bool MoveMage(char* p_mageinfo, PPOINT p_pos, int p_key ); // p_pos 위치에 벽이 있으면 true, false를 반환하려고함
void SetBoom(char(*)[GRIDMAPSIZEX], PPOINT p_pos);
void SetBoomFire(char(*p_mage)[GRIDMAPSIZEX]);
void SetRoundFire(char(*p_mage)[GRIDMAPSIZEX], PPOINT p_centerpos, int p_power);
void CreateRandomItem(char(*p_mage)[GRIDMAPSIZEX], int p_x, int p_y);
void WallPushPlayer(int p_key, char(*p_mageinfo)[GRIDMAPSIZEX]);
void ThrowWallPlayer(int p_key, char(*p_mageinfo)[GRIDMAPSIZEX]);


/// <summary>
/// 메인함수
/// </summary>
/// <returns></returns>
int main()
{
    // 랜덤시드 기본 세팅
    srand( (unsigned int)time(NULL) );



    //POINT startpos = { 0,0 };
    //POINT endpos = { 9, 18 };
    //char MageInfo[10][20] = {
    //      "  11111111111111111"
    //    , "1      1111     111"
    //    //, "S11111 1111 1111111"
    //    , "S     1            "
    //    , "111111      1111111"
    //    , "111111 111111111111"
    //    , "111111 111111111111"
    //    , "111111 111111111111"
    //    , "111111        11111"
    //    , "111111 111111 11111"
    //    , "1111111111111   E11"
    //};


    char MageInfo[10][20] = {
          "      1111111111111"
        , "     S11111     111"
        , "   1     1         "
        , "     1      1111111"
        , " 11 11 111111111111"
        , " 11 11 111111111111"
        , "111 11 111111111111"
        , " 11 11        11111"
        , "111 11 111111 11111"
        , "111 111111111   E11"
    };

    /*MageInfo[0][0] = 'a';
    char* temppos = &MageInfo[0][0];*/



    g_pPlayerdata = new PlayerInfoData();
    g_pPlayerdata->Init();

    // 전처리기
#if _DEBUG
    //g_pPlayerdata->Ghost = true; // 벽뚫기 테스트
    //g_pPlayerdata->WallPush = true; // 벽밀기 테스트
    g_pPlayerdata->WallThrow = true; // 벽던지기 테스트
#endif // 0

    

    bool isbreak = false;
    for (int y = 0; y < GRIDMAPSIZEY; y++)
    {
        for (int x = 0; x < GRIDMAPSIZEX; x++)
        {
            if (MageInfo[y][x] == 'S')
            {
                g_pPlayerdata->X = x;
                g_pPlayerdata->Y = y;
                isbreak = true;
                break;
            }
        }

        if (isbreak)
            break;
    }


    POINT playerpos;
    
    while (true) 
    {
        system("cls");
        PrintMage(MageInfo);

        // 키보드 키를 누루기 전까지 멈추게됨
        int keypressinfo = _getch();

        // 화살표 키를 눌렀을때 사용하기 위한 값들
        if (keypressinfo == 224)
        {
            keypressinfo = _getch();
        }

        playerpos.x = g_pPlayerdata->X;
        playerpos.y = g_pPlayerdata->Y;

        if (SPACEKEY == keypressinfo )
        {
            SetBoom( MageInfo , &playerpos);
        }
        if ( 'f' == keypressinfo)
        {
            SetBoomFire(MageInfo);
        }

        bool ismove = MoveMage( &MageInfo[0][0], &playerpos, keypressinfo );
        if ( ismove )
        {
            if (g_pPlayerdata->WallThrow)
            {
                ThrowWallPlayer(keypressinfo, MageInfo);

            }
            else if (g_pPlayerdata->WallPush)
            {
                // 벽을 밀수 있을때
                WallPushPlayer(keypressinfo, MageInfo);
            }
            else
            {
                // 일반이동
                MovePlayer(keypressinfo, MageInfo);
            }
        }
    }
    
    //pPlayerdata = NULL; // 스마트 포인터 기법
    SAFEDELETE(g_pPlayerdata);
}

void ThrowWallPlayer(int p_key, char(*p_mageinfo)[GRIDMAPSIZEX])
{
    POINT playerpos = { g_pPlayerdata->X, g_pPlayerdata->Y };
    int posx = g_pPlayerdata->X;
    int posy = g_pPlayerdata->Y;


    if (p_key == LEFTARROW || p_key == 'a')
    {

        if (posx >= 1)
        {
            if (p_mageinfo[posy ][posx - 1] == ' '
                || p_mageinfo[posy][posx - 1] == 'S'
                || p_mageinfo[posy][posx - 1] == 'E'
                )
            {
                g_pPlayerdata->X -= 1;
            }

            if (posx >= 2)
            {
                if (p_mageinfo[posy][posx - 1] == '1'
                    && p_mageinfo[posy][posx - 2] == ' ')
                {
                    g_pPlayerdata->WallThrow = false;
                    for (int x = posx - 2; x >= 0; --x)
                    {
                        if (p_mageinfo[posy][x] == '1')
                        {
                            p_mageinfo[posy][x + 1] = p_mageinfo[posy][posx - 1];
                            p_mageinfo[posy][posx - 1] = ' ';
                            break;
                        }

                        if (x == 0)
                        {
                            p_mageinfo[posy][x] = p_mageinfo[posy][posx - 1];
                            p_mageinfo[posy][posx - 1] = ' ';
                        }
                    }

                }
            }

        }
    }
    else if (p_key == RIGHTARROW || p_key == 'd')
    {
        if (posx <= GRIDMAPSIZEX - 4 )
        {
            if (p_mageinfo[posy][posx + 1] == ' '
                || p_mageinfo[posy][posx + 1] == 'S'
                || p_mageinfo[posy][posx + 1] == 'E'
                )
            {
                g_pPlayerdata->X += 1;
            }

            if (posx <= GRIDMAPSIZEX - 5)
            {
                if (p_mageinfo[posy][posx + 1] == '1'
                    && p_mageinfo[posy][posx + 2] == ' ')
                {
                    g_pPlayerdata->WallThrow = false;
                    for (int x = posx + 2; x < GRIDMAPSIZEX - 2; ++x)
                    {
                        if (p_mageinfo[posy][x] == '1')
                        {
                            p_mageinfo[posy][x - 1] = p_mageinfo[posy][posx + 1];
                            p_mageinfo[posy][posx + 1] = ' ';
                            break;
                        }

                        if (posx == GRIDMAPSIZEX - 3)
                        {
                            p_mageinfo[posy][x] = p_mageinfo[posy][posx + 1];
                            p_mageinfo[posy][posx + 1] = ' ';
                        }
                    }

                }
            }

        }
    }
    // 아래 이동
    else if (p_key == DOWNARROW || p_key == 's')
    {
        if (posy <= GRIDMAPSIZEY - 2)
        {
            if (p_mageinfo[posy + 1][posx] == ' '
                || p_mageinfo[posy + 1][posx] == 'S'
                || p_mageinfo[posy + 1][posx] == 'E'
                )
            {
                g_pPlayerdata->Y += 1;
            }

            if (posy <= GRIDMAPSIZEY - 3)
            {
                if ( (p_mageinfo[posy + 1][posx] == '1' )
                    && p_mageinfo[posy + 2][posx] == ' ')
                {
                    g_pPlayerdata->WallThrow = false;
                    //g_pPlayerdata->Y += 1;
                    for (int y = posy + 2; y < GRIDMAPSIZEY; y++)
                    {
                        if (p_mageinfo[y][posx] == '1')
                        {
                            p_mageinfo[y - 1][posx] = p_mageinfo[posy + 1][posx];
                            p_mageinfo[posy + 1][posx] = ' ';
                            break;
                        }

                        if (y == GRIDMAPSIZEY - 1)
                        {
                            p_mageinfo[y][posx] = p_mageinfo[posy + 1][posx];
                            p_mageinfo[posy + 1][posx] = ' ';
                        }
                    }


                }
            }
        }
    }
    else if (p_key == UPARROW || p_key == 'w')
    {
        // 위로 이동부분
        if (posy >= 1)
        {
            if (p_mageinfo[posy - 1][posx] == ' '
                || p_mageinfo[posy - 1][posx] == 'S'
                || p_mageinfo[posy - 1][posx] == 'E' )
            {
                g_pPlayerdata->Y -= 1;
            }

            if (posy >= 2)
            {
                if (p_mageinfo[posy - 1][posx] == '1'
                    && p_mageinfo[posy - 2][posx] == ' ')
                {
                    g_pPlayerdata->WallThrow = false;

                    //g_pPlayerdata->Y -= 1;
                    for (int y = posy - 2; y >= 0; --y)
                    {
                        if ( p_mageinfo[y][posx] == '1')
                        {
                            p_mageinfo[y + 1][posx] = p_mageinfo[posy - 1][posx];
                            p_mageinfo[posy - 1][posx] = ' ';
                            break;
                        }

                        if (y == 0)
                        {
                            p_mageinfo[y][posx] = p_mageinfo[posy - 1][posx];
                            p_mageinfo[posy - 1][posx] = ' ';
                        }
                    }
                }
            }
            

        }


    }



}

void CreateRandomItem(char(*p_mage)[GRIDMAPSIZEX], int p_x, int p_y )
{
    int randval = rand() % 101;

    // 범위 관련 부분
    //if (randval <= 0 && randval < 40)
    //{
    //}
    //if (randval <= 40 && randval < 60)
    //{
    //}
    //if (randval <= 60 && randval < 70)
    //{
    //}

    // 테스트용
    //randval = 75;


    if (randval > 90)
    {
        // 10 프로확율
        p_mage[p_y][p_x] = WALLGHOST;
    }
    else if (randval > 80)
    {
        p_mage[p_y][p_x] = WALLPUSH;
    }
    else if (randval > 70)
    {
        p_mage[p_y][p_x] = BOOMPOWER;
    }
    else if (randval > 40)
    {
        p_mage[p_y][p_x] = BOOMITEM;
    }
    else
    {
        // 40프로 확율
        //p_mage[p_y][p_x] = BOOMITEM;
        
    }

}

void SetRoundFire(char(*p_mage)[GRIDMAPSIZEX], PPOINT p_centerpos, int p_power)
{
    int tempx = p_centerpos->x;
    int tempy = p_centerpos->y;

    for (int i = 1; i <= p_power; i++)
    {
        int pow = i;

        // 오른쪽
        if (tempx + pow < GRIDMAPSIZEX - 1)
        {
            if (p_mage[tempy][tempx + pow] == '1')
            {
                p_mage[tempy][tempx + pow] = ' ';
                CreateRandomItem(p_mage, tempx + pow, tempy);
            }

            if (tempx + pow == g_pPlayerdata->X && tempy == g_pPlayerdata->Y)
            {
                --g_pPlayerdata->LifeCount;
                if (g_pPlayerdata->LifeCount <= 0)
                {
                    // 게임 오버
                    //OutputDebugString(L"게임오버");
                    assert(NULL && "게임오버");
                }
                g_pPlayerdata->X = 0;
                g_pPlayerdata->Y = 0;
            }
        }

        // 왼쪽
        if (tempx - pow >= 0)
        {
            if (p_mage[tempy][tempx - pow] == '1')
            {
                p_mage[tempy][tempx - pow] = ' ';
                CreateRandomItem(p_mage, tempx - pow, tempy);
            }

            if (tempx - pow == g_pPlayerdata->X && tempy == g_pPlayerdata->Y)
            {
                --g_pPlayerdata->LifeCount;
                if (g_pPlayerdata->LifeCount <= 0)
                {
                    // 게임 오버
                    //OutputDebugString(L"게임오버");
                    assert(NULL && "게임오버");
                }
                g_pPlayerdata->X = 0;
                g_pPlayerdata->Y = 0;
            }
        }

        // 상단
        if (tempy - pow >= 0)
        {
            if (p_mage[tempy - pow][tempx] == '1')
            {
                p_mage[tempy - pow][tempx] = ' ';
                CreateRandomItem(p_mage, tempx, tempy - pow);
            }

            if (tempx == g_pPlayerdata->X && tempy - pow == g_pPlayerdata->Y)
            {
                --g_pPlayerdata->LifeCount;
                if (g_pPlayerdata->LifeCount <= 0)
                {
                    // 게임 오버
                    //OutputDebugString(L"게임오버");
                    assert(NULL && "게임오버");
                }
                g_pPlayerdata->X = 0;
                g_pPlayerdata->Y = 0;
            }
        }

        // 하단
        if (tempy + pow < GRIDMAPSIZEY)
        {
            if (p_mage[tempy + pow][tempx] == '1')
            {
                p_mage[tempy + pow][tempx] = ' ';
                CreateRandomItem(p_mage, tempx, tempy + pow);
            }

            if (tempx == g_pPlayerdata->X && tempy + pow == g_pPlayerdata->Y)
            {
                --g_pPlayerdata->LifeCount;
                if (g_pPlayerdata->LifeCount <= 0)
                {
                    // 게임 오버
                    //OutputDebugString(L"게임오버");
                    assert(NULL && "게임오버");
                }
                g_pPlayerdata->X = 0;
                g_pPlayerdata->Y = 0;
            }
        }
    }
    

}

void SetBoomFire(char(*p_mage)[GRIDMAPSIZEX])
{
    //g_BoomCount = 5;

    for (int y = 0; y < GRIDMAPSIZEY; y++)
    {
        for (int x = 0; x < GRIDMAPSIZEX; x++)
        {
            if ( p_mage[y][x] == '2'
                || p_mage[y][x] >= 'E' + 20 )
            {
                if (x == g_pPlayerdata->X && y == g_pPlayerdata->Y)
                {
                    --g_pPlayerdata->LifeCount;
                    if (g_pPlayerdata->LifeCount <= 0)
                    {
                        // 게임 오버
                        //OutputDebugString( L"게임오버" );
                        assert(NULL && "게임오버");
                    }
                    g_pPlayerdata->X = 0;
                    g_pPlayerdata->Y = 0;
                }

                if (p_mage[y][x] >= 'E' + 20)
                {
                    p_mage[y][x] -= 20;
                }
                else
                {
                    p_mage[y][x] = ' ';
                }
                //  
                POINT centerpos = { x, y };
                SetRoundFire( p_mage, &centerpos, g_pPlayerdata->Power);

            }
        }
    }

}

void SetBoom(char(*p_mage)[GRIDMAPSIZEX], PPOINT p_pos)
{
    if (g_BoomCount <= 0)
        return;

    // 같은 위치에 폭탄이 있을시에 
    if (p_mage[p_pos->y][p_pos->x] == '2'
        || p_mage[p_pos->y][p_pos->x] >= 'E' + 20)
        return;


    --g_BoomCount;
    if (p_mage[p_pos->y][p_pos->x] == 'S'
        || p_mage[p_pos->y][p_pos->x] == 'E')
    {
        p_mage[p_pos->y][p_pos->x] += 20; // 폭탄
    }
    else
    {
        p_mage[p_pos->y][p_pos->x] = '2'; // 폭탄
    }
    
}

/// <summary>
/// 미로정보를 이용한 이동 가능 여부
/// </summary>
/// <param name="p_mageinfo"> 미로정보 2차원 -> 1차원 </param>
/// <param name="p_pos">현재위치</param>
/// <param name="p_key">이동할 키값</param>
/// <returns>이동이면 ture </returns>
bool MoveMage(char* p_mageinfo, PPOINT p_pos, int p_key)
{
    // 2차원에 값을 1차원으로 사용
    if (p_key == RIGHTARROW
        || p_key == 'd')
    {
        p_pos->x += 1;
    }
    else if (p_key == LEFTARROW
        || p_key == 'a')
    {
        p_pos->x -= 1;
    }
    else if (p_key == UPARROW
        || p_key == 'w')
    {
        p_pos->y -= 1;
        
    }
    else if (p_key == DOWNARROW
        || p_key == 's')
    {
        p_pos->y += 1;
    }

    if (g_pPlayerdata->Ghost)
    {
        if ( p_mageinfo[(p_pos->y * GRIDMAPSIZEX) + p_pos->x] == '1'
            || p_mageinfo[(p_pos->y * GRIDMAPSIZEX) + p_pos->x] == BOOM
            )
            g_pPlayerdata->MoveGhost = true;

        return true;
    }

    if ( g_pPlayerdata->WallPush )
    {
        return true;
    }

    if (g_pPlayerdata->WallThrow)
    {
        if (p_mageinfo[(p_pos->y * GRIDMAPSIZEX) + p_pos->x] == '1')
            return true;
    }

    if ( p_mageinfo[(p_pos->y * GRIDMAPSIZEX) + p_pos->x] == '1'
        || p_mageinfo[(p_pos->y * GRIDMAPSIZEX) + p_pos->x] == '2'
        )
    {
        return false;
    }
    
    return true;
}


// 벽을 한칸씩 이동 하기
void WallPushPlayer(int p_key, char(*p_mageinfo)[GRIDMAPSIZEX])
{
    POINT playerpos = { g_pPlayerdata->X, g_pPlayerdata->Y };
    int posx = g_pPlayerdata->X;
    int posy = g_pPlayerdata->Y;


    // 아래 이동
    if (p_key == DOWNARROW || p_key == 's')
    {
        if ( posy <= GRIDMAPSIZEY - 2 )
        {
            if (p_mageinfo[posy + 1][posx] == ' ')
            {
                g_pPlayerdata->Y += 1;
            }

            if (posy <= GRIDMAPSIZEY - 3)
            {
                if ( ( p_mageinfo[posy + 1][posx] == '1'
                    || p_mageinfo[posy + 1][posx] == BOOM
                    )
                    && p_mageinfo[posy + 2][posx] == ' ')
                {
                    g_pPlayerdata->Y += 1;
                    p_mageinfo[posy + 2][posx] = p_mageinfo[posy + 1][posx];
                    p_mageinfo[posy + 1][posx] = ' ';
                }
            }
        }
    }
    // 왼쪽이동
    else if (p_key == LEFTARROW || p_key == 'a')
    {
        if ( posx >= 1 ) // 플레이어 움직일수 있는 최소조건
        {
            if (p_mageinfo[posy][posx - 1] == ' ')
            {
                g_pPlayerdata->X -= 1;
            }

            if (posx >= 2 )
            {
                if ((p_mageinfo[posy][posx - 1] == '1'
                    || p_mageinfo[posy][posx - 1] == BOOM)
                    && p_mageinfo[posy][posx - 2] == ' ')
                {
                    g_pPlayerdata->X -= 1;
                    p_mageinfo[posy][posx - 2] = p_mageinfo[posy][posx - 1];
                    p_mageinfo[posy][posx - 1] = ' ';
                }
            }
        }
    }
    else if (p_key == RIGHTARROW
        || p_key == 'd')
    {
        // 오른쪽 이동시
        if (posx < GRIDMAPSIZEX - 2)
        {
            // 진행방향에 길이다
            if ( p_mageinfo[posy][posx + 1] == ' ')
            {
                g_pPlayerdata->X += 1;
            }

            if (posx + 2 <= GRIDMAPSIZEX - 2)
            {
                // 진행방향에 벽이다
                if ( (p_mageinfo[posy][posx + 1] == '1'
                    || p_mageinfo[posy][posx + 1] == BOOM)
                    && p_mageinfo[posy][posx + 2] == ' ')
                {
                    g_pPlayerdata->X += 1;
                    p_mageinfo[posy][posx + 2] = p_mageinfo[posy][posx + 1];
                    p_mageinfo[posy][posx + 1] = ' ';
                }
            }
            
        }
    }
    else if (p_key == UPARROW
        || p_key == 'w')
    {
        // 위로 이동시
        if ( (p_mageinfo[posy - 1][posx] == '1' // 위방향에 블럭이 있고
            || p_mageinfo[posy - 1][posx] == BOOM)
            && p_mageinfo[posy - 2][posx] == ' ' // 진행방향에 블럭이 없어야지됨
            )
        {
            // 상단에 무엇인가 없을때
            if (posy - 1 >= 0
                && posy - 2 >= 0)
            {
                p_mageinfo[posy - 2][posx] = p_mageinfo[posy - 1][posx];
                p_mageinfo[posy - 1][posx] = ' ';
                g_pPlayerdata->Y -= 1;
            }
        }
        else if (p_mageinfo[posy - 1][posx] == ' ')
        {
            if (posy - 1 >= 0)
            {
                g_pPlayerdata->Y -= 1;
            }
        }
        

    }
}

void MovePlayer( int p_key, char(*p_mageinfo)[GRIDMAPSIZEX] )
{
    if (p_key == RIGHTARROW
        || p_key == 'd')
    {
        g_pPlayerdata->X += 1;
        if (g_pPlayerdata->X >= GRIDMAPSIZEX - 2) g_pPlayerdata->X = GRIDMAPSIZEX - 2;
    }
    else if (p_key == LEFTARROW
        || p_key == 'a')
    {
        g_pPlayerdata->X -= 1;
        if (g_pPlayerdata->X < 0) g_pPlayerdata->X = 0;
    }
    else if (p_key == UPARROW
        || p_key == 'w')
    {
        g_pPlayerdata->Y -= 1;
        if (g_pPlayerdata->Y < 0) g_pPlayerdata->Y = 0;
    }
    else if (p_key == DOWNARROW
        || p_key == 's')
    {
        g_pPlayerdata->Y += 1;
        if (g_pPlayerdata->Y >= GRIDMAPSIZEY - 1) g_pPlayerdata->Y = GRIDMAPSIZEY - 1;
    }

    
    if ( g_pPlayerdata->MoveGhost
        && ( p_mageinfo[g_pPlayerdata->Y][g_pPlayerdata->X] == ROAD )
        )
    {
        g_pPlayerdata->Ghost = false;
        g_pPlayerdata->MoveGhost = false;
    }



    //// 아이템 처리
    //if ( p_mageinfo[g_pPlayerdata->Y][g_pPlayerdata->X] >= BOOMITEM
    //    && p_mageinfo[g_pPlayerdata->Y][g_pPlayerdata->X] <= BOOMPOWER )
    //{
    //    // 등록하기
    //}

    if (p_mageinfo[g_pPlayerdata->Y][g_pPlayerdata->X] == BOOMITEM)
    {
        g_BoomCount++;
        p_mageinfo[g_pPlayerdata->Y][g_pPlayerdata->X] = ' ';
    }

    if (p_mageinfo[g_pPlayerdata->Y][g_pPlayerdata->X] == BOOMPOWER)
    {
        ++g_pPlayerdata->Power;

        if (g_pPlayerdata->Power >= MAXBOOMPOWER)
        {
            g_pPlayerdata->Power = MAXBOOMPOWER;
        }

        p_mageinfo[g_pPlayerdata->Y][g_pPlayerdata->X] = ' ';
    }

    if (p_mageinfo[g_pPlayerdata->Y][g_pPlayerdata->X] == WALLPUSH)
    {
        p_mageinfo[g_pPlayerdata->Y][g_pPlayerdata->X] = ' ';
        g_pPlayerdata->WallPush = true;
    }

    if (p_mageinfo[g_pPlayerdata->Y][g_pPlayerdata->X] == WALLGHOST)
    {
        p_mageinfo[g_pPlayerdata->Y][g_pPlayerdata->X] = ' ';
        g_pPlayerdata->Ghost = true;
    }
}

/// <summary>
/// 맵 그리기
/// </summary>
void PrintMage( char (*p_mageinfo)[20] )
{
    //cout << "S#############" << endl;
    //cout << "  @   ########" << endl;
    //cout << "##### ########" << endl;
    //cout << "##### ########" << endl;
    //cout << "##### ########" << endl;
    //cout << "##### ########" << endl;
    //cout << "#####   ######" << endl;
    //cout << "#######    &##" << endl;


    //p_mageinfo[0][0] = 'a';


    // 2차원 배열을 통한 화면 출력
    for (int y = 0; y < 10; y++)
    {
        for (int x = 0; x < 20; x++)
        {
            if ( x == g_pPlayerdata->X && y == g_pPlayerdata->Y )
            {
                //@ <- 1byte
                cout << "＠"; // 2byte
            }
            else if (p_mageinfo[y][x] == '1')
            {
                cout << "■"; // 2byte
            }
            else if (p_mageinfo[y][x] == '2'
                || p_mageinfo[y][x] == 'S' + 20
                || p_mageinfo[y][x] == 'E' + 20
                )
            {
                // 폭탄
                cout << "♨"; // 2byte
            }
            else if (p_mageinfo[y][x] == ' ')
            {
                cout << "  "; // 2byte
            }
            else if (p_mageinfo[y][x] == 'S')
            {
                cout << "◐"; // 2byte
            }
            else if (p_mageinfo[y][x] == 'E')
            {
                cout << "◑"; // 2byte
            }
            else if (p_mageinfo[y][x] == BOOMITEM)
            {
                cout << "◎"; // 2byte
            }
            else if (p_mageinfo[y][x] == BOOMPOWER)
            {
                cout << "㉿"; // 2byte
            }
            else if (p_mageinfo[y][x] == WALLPUSH)
            {
                cout << "◈"; // 2byte
            }
            else if (p_mageinfo[y][x] == WALLGHOST)
            {
                cout << "♥"; // 2byte
            }
            else
            {
                cout << p_mageinfo[y][x];
            }
        }
        cout << endl;// "\n";
    }
    
    // 폭탄 갯수 정보
    cout << endl << endl;

    cout << "총폭탄 갯수 : " << g_BoomCount<< endl;
    cout << "플레이어파워값 : " << g_pPlayerdata->Power << endl;
    cout << "플레이어 상태 : " << "고스트 : " << g_pPlayerdata->Ghost 
        << ", 벽밀기 : " << g_pPlayerdata->WallPush << ", 벽던지기" << g_pPlayerdata->WallThrow  <<  endl;
    cout << "플레이어 목숨 : " << g_pPlayerdata->LifeCount << endl;

}



// 프로그램 실행: <Ctrl+F5> 또는 [디버그] > [디버깅하지 않고 시작] 메뉴
// 프로그램 디버그: <F5> 키 또는 [디버그] > [디버깅 시작] 메뉴

// 시작을 위한 팁: 
//   1. [솔루션 탐색기] 창을 사용하여 파일을 추가/관리합니다.
//   2. [팀 탐색기] 창을 사용하여 소스 제어에 연결합니다.
//   3. [출력] 창을 사용하여 빌드 출력 및 기타 메시지를 확인합니다.
//   4. [오류 목록] 창을 사용하여 오류를 봅니다.
//   5. [프로젝트] > [새 항목 추가]로 이동하여 새 코드 파일을 만들거나, [프로젝트] > [기존 항목 추가]로 이동하여 기존 코드 파일을 프로젝트에 추가합니다.
//   6. 나중에 이 프로젝트를 다시 열려면 [파일] > [열기] > [프로젝트]로 이동하고 .sln 파일을 선택합니다.

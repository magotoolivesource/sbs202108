#include "pch.h"
#include "Player.h"
#include <windows.h>


using namespace std;

Player::Player()
{
	CONSOLE_CURSOR_INFO info;
	GetConsoleCursorInfo(GetStdHandle(STD_OUTPUT_HANDLE), &info);
	info.bVisible = false; // set the cursor visibility
	SetConsoleCursorInfo(GetStdHandle(STD_OUTPUT_HANDLE), &info);
}

Player::~Player()
{
}

void Player::Init( const MPOINT* const p_startpos
	, MPOINT* const p_stagesize)
{
	m_Pos.X = p_startpos->X;
	m_Pos.Y = p_startpos->Y;

	m_StageSize.X = p_stagesize->X;
	m_StageSize.Y = p_stagesize->Y;

	m_pStageSize = p_stagesize;
}

void Player::AddMove(int p_x, int p_y)
{
	m_Pos.X += p_x;
	m_Pos.Y += p_y;

	if (m_Pos.X < 0)
		m_Pos.X = 0;
	if (m_Pos.Y < 0)
		m_Pos.Y = 0;

	if (m_StageSize.X - 2 <= m_Pos.X)
	{
		m_Pos.X = m_StageSize.X - 2;
	}

	if (m_StageSize.Y - 1 <= m_Pos.Y)
	{
		m_Pos.Y = m_StageSize.Y - 1;
	}

}

void Player::PrintPlayer()
{
	// �ش� ��ġ�� �̵� �ϱ�
	COORD cur;
	cur.X = m_Pos.X * 2;
	cur.Y = m_Pos.Y;

	//PCONSOLE_CURSOR_INFO info;
	//GetConsoleCursorInfo(GetStdHandle(STD_OUTPUT_HANDLE), info);0
	SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), cur);
	cout << "��"; // 2byte


	//printf("��");
}

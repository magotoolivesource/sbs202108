#include "pch.h"
#include <iostream>
//#include <cstdlib> // c stdlib.h
#include <conio.h> // getch �Լ� ����ϱ� ���� ���
//#include <Windows.h>
#include <cassert> // c assert.h
#include <winerror.h>
#include "Stage.h"
#include "Player.h"


int main()
{
	Stage* stage = new Stage();
	stage->Init();

	Player* player = new Player();
	player->Init( stage->GetStartPos(), stage->GetMapSize() );

	while (true)
	{
		system("cls");
		stage->PrintStageMap();
		player->PrintPlayer();


		int keypressinfo = _getch();

		if ( keypressinfo == 'w' )
		{
			player->AddMove(0, -1);
		}
		else if (keypressinfo == 's')
		{
			player->AddMove(0, 1);
		}
		else if (keypressinfo == 'a')
		{
			player->AddMove(-1, 0);
		}
		else if (keypressinfo == 'd')
		{
			player->AddMove(1, 0);
		}


	}
	

	
	delete player;
	delete stage;

	return S_OK;
}

#pragma once
#include "MPoint.h"


#define GRIDMAPSIZEX 20
#define GRIDMAPSIZEY 10

// �� ����
#define WALL '1'
#define ROAD ' '
#define STARTPOINT 'S'
#define ENDPOINT 'E'
#define BOOM '2'
#define SBOOM 'S' + 20
#define EBOOM 'E' + 20



class Stage
{
public:
	Stage();
	virtual ~Stage();

protected:
	char m_MageInfo[10][20];
	
	MPOINT m_MapSize;
	MPOINT m_StartPos;
	MPOINT m_EndPos;

public:
	void Init(); // �ʱ�ȭ
	void PrintStageMap();

	MPOINT* GetStartPos();
	MPOINT* GetMapSize();
};


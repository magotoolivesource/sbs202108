#include "pch.h"
#include "Stage.h"


using namespace std;

Stage::Stage()
{
	//Init();
}

Stage::~Stage()
{

}

MPOINT* Stage::GetStartPos()
{
    return &m_StartPos;
}

MPOINT* Stage::GetMapSize()
{
    return &m_MapSize;
}

void Stage::Init()
{
    // �ӽ� �ʰ�
    char temp[10][20] = {
          "      1111111111111"
        , "     S11111     111"
        , "   1     1         "
        , "     1      1111111"
        , " 11 11 111111111111"
        , " 11 11 111111111111"
        , "111 11 111111111111"
        , " 11 11        11111"
        , "111 11 111111 11111"
        , "111 111111111   E11"
    };


    m_MapSize.X = GRIDMAPSIZEX;
    m_MapSize.Y = GRIDMAPSIZEY;
    for (int y = 0; y < m_MapSize.Y; y++)
    {
        for (int x = 0; x < m_MapSize.X; x++)
        {
            m_MageInfo[y][x] = temp[y][x];

            if (m_MageInfo[y][x] == STARTPOINT)
            {
                m_StartPos.X = x;
                m_StartPos.Y = y;
            }

            if (m_MageInfo[y][x] == ENDPOINT)
            {
                m_EndPos.X = x;
                m_EndPos.Y = y;
            }
        }
    }
}

void Stage::PrintStageMap()
{
    for (int y = 0; y < m_MapSize.Y; y++)
    {
        for (int x = 0; x < m_MapSize.X; x++)
        {

            if (m_MageInfo[y][x] == WALL)
            {
                cout << "��"; // 2byte
            }
            else if (m_MageInfo[y][x] == ROAD)
            {
                cout << "  "; // 2byte
            }
            else if (m_MageInfo[y][x] == STARTPOINT)
            {
                cout << "��"; // 2byte
            }
            else if (m_MageInfo[y][x] == ENDPOINT)
            {
                cout << "��"; // 2byte
            }
        }

        cout << endl;
    }

    // ��ź ���� ����
    cout << endl << endl;

    cout << "������ : "<< endl;




}



#pragma once


typedef struct MPOINT
{
	int X, Y;
}MVECTOR, *PMPOINT;

#include "Phone.h"
#include <iostream>
using namespace std;


void Phone::EXZoom()
{
	this->Zoom(2);

}

void Phone::TestFN()
{

}
void Phone::CallUp(int number)
{
	cout << "Call up... " << number << endl;
}

void Phone::HangUp(void)
{
	cout << "Hang up... " << endl;
}

#include <iostream>
#include "Ellipse.h"
using namespace std;



Ellipse::Ellipse(int x, int y, int width, int height)
	: Figure(x, y, width, height)
{
}

void Ellipse::Draw()
{
	cout << "Draw Ellipse: ";
	cout << "(" << x << ", " << y << "), ";
	cout << width << " x " << height;
	cout << endl;

	//__super::Draw();
}

#pragma once
#include "Figure.h"
#include <iostream>
using namespace std;

class Rectangle : public Figure
{
public:
	Rectangle(int x, int y, int width, int height) :
		Figure(x, y, width, height)
	{

	}
	virtual ~Rectangle()
	{

	}
	virtual void Draw();		// �������̵�
};

void Rectangle::Draw()
{
	cout << "Draw RectAngle: ";
	cout << "(" << x << ", " << y << "), ";
	cout << width << " x " << height;
	cout << endl;

}

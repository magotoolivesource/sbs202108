#include "Camera.h"
#include <iostream>
using namespace std;


void Camera::Photograph(void)
{
	cout << "Take a photo..." << endl;
}

void Camera::Zoom(int zoom)
{
	cout << "Zoom..." << zoom << endl;
}

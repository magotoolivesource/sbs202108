#pragma once
class Camera
{
public:
	void Photograph(void);
	void Zoom(int zoom);
};


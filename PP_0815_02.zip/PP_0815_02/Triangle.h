#pragma once
#include "Figure.h"
#include <iostream>
using namespace std;

class Triangle : public Figure
{
public:
	Triangle(int x, int y, int width, int height) :
		Figure(x, y, width, height)
	{

	}
	virtual ~Triangle()
	{

	}
	virtual void Draw();		// �������̵�
};

void Triangle::Draw()
{
	cout << "Draw Triabgle: ";
	cout << "(" << x << ", " << y << "), ";
	cout << width << " x " << height;
	cout << endl;
}
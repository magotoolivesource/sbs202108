#include <iostream>
#include "Rectangle.h"
#include "Triangle.h"
#include "Ellipse.h"
#include "Camera.h"
#include "Phone.h"

using namespace std;

#define FIGURESIZE 4
void main()
{

	Phone pphone(10);
	
	//pphone.GetCamera().Zoom(10);
	//pphone.EXZoom()



	Figure* tempval[FIGURESIZE] = {
		new Triangle(1, 2, 10, 10)
		, new Rectangle(5, 5, 11, 12)
		, new Ellipse(7, 3, 20, 20)
		, new Ellipse(17, 13, 30, 30)
		//, new Figure(2, 3, 5, 6)
	};

	delete tempval[0];
	for (int i = 0; i < FIGURESIZE; i++)
	{
		tempval[i]->Draw();
	}

	delete[] tempval;


	//Figure ff(1, 2, 10, 10);
	//Triangle tri(1, 2, 10, 10);
	//Rectangle rect(5, 5, 11, 12);
	//Ellipse elip(7, 3, 20, 20);

	//// �迭 �����
	//Figure* tempval[3];
	//tempval[0] = &tri;
	//tempval[1] = &rect;
	//tempval[2] = &elip;

	//for (int i = 0; i < 3; i++)
	//{
	//	tempval[i]->Draw();
	//}

	////tempval = &tri;
	////tempval->Draw();
	////tempval = &elip;
	////tempval->Draw();

	//tri.Draw();
	//rect.Draw();
	//elip.Draw();


}

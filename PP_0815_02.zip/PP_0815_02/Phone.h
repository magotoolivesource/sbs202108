#pragma once
#include "Camera.h"

class Phone : Camera
{
	Phone();
	void TestFN();

public:
	Phone(int p_val);

	void CallUp(int number);
	void HangUp(void);

	void EXZoom();


//	Camera& GetCamera()
//	{
//		return m_Camera;
//	}
//
//private:
//	Camera m_Camera;

};



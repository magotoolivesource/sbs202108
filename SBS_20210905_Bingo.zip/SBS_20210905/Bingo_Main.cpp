#include <iostream>
#include <cstdlib> // c <stdlib.h>
#include <ctime> // c <time.h>
//#include "Bingo_C.h"
#include <Windows.h>
#include <cassert> // c <assert.h>
#include "cBingo.h" 

using namespace std;

void main()
{
	srand(time(NULL));


	cBingo playerbingo;
	playerbingo.TestFN();


	while ( true )
	{
		system("cls");
		playerbingo.PrintBingo();
		cout << "�������� : " << playerbingo.GetBingoCount() << endl;


		int inputval = -1;
		cout << "������ȣ�� �Է��ϼ��� : ";
		cin >> inputval;

	}


	//int srcval = 10;
	//int destval = 20;
	//CoreFN::SwapVal( srcval, destval );



}

#pragma once

#define BIGOSIZE 5

class CoreFN
{
public:
	static void SwapVal(int& p_src, int& p_dest)
	{
		int tempval = p_src;
		p_src = p_dest;
		p_dest = tempval;
	}
};

class cBingo
{
public:
	cBingo();
	virtual ~cBingo();

	void InitBingo( bool p_isrand = true );
	int GetBingoCount();
	void PrintBingo();
	void UpdateBingoCount();


	void TestFN();

	

protected:
	int m_Bingo2byarr[BIGOSIZE][BIGOSIZE] = { 0, };
	int m_BingoCount = 0;
	

};


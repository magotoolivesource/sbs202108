#include <iostream>
#include <cstdlib> // c <stdlib.h>
#include <ctime> // c <time.h>
#include "Bingo_C.h"
#include <Windows.h>
#include <cassert> // c <assert.h>

using namespace std;


#define BIGOSIZE 5
void BingoPrint(int* bingo2byarr);

//std::vector

void InitTest(int* p_val)
{
	*p_val = 20;
}

void SwapVal(int& p_src, int& p_dest)
{
	int tempval = p_src;
	p_src = p_dest;
	p_dest = tempval;
}
void InitBingo( int (*p_bingo)[BIGOSIZE], bool p_isrand = true )
{
	for (int y = 0; y < 5; y++)
	{
		for (int x = 0; x < 5; x++)
		{
			p_bingo[y][x] = ((y * 5) + x) + 1;
		}
	}


	if (p_isrand)
	{
		for (int i = 0; i < 15; i++)
		{
			// ���� ��ġ
			int x = i % 5;
			int y = int(i / 5);

			// ������ġ
			int temprand = rand() % 25;
			int sx = temprand % 5;
			int sy = (int)(temprand / 5);

			// �� ���� 
			SwapVal(p_bingo[y][x], p_bingo[sy][sx]);
		}
	}
	
}

int GetBingoCount(int* p_bingo)
{
	int bingocount = 0;
	// ��ü������ �Ǿ��ִ°�

	int xline = 0;
	int yline = 0;
	for (int i = 0; i < 5; i++)
	{
		yline = xline = 0;

		for (int j = 0; j < 5; j++)
		{
			// x�� ���� �ڷ�
			if (p_bingo[(i * 5) + j] == -1)
			{
				++xline;
			}
			if (p_bingo[(j * 5) + i] == -1)
			{
				++yline;
			}
		}

		if (xline == 5)
		{
			++bingocount;
		}

		if (yline == 5)
		{
			++bingocount;
		}

	}


	// ũ�ν� �޻��, �������
	int tempcrossLT = 0;
	int tempcrossRT = 0;
	for (int i = 0; i < 25; i += 6)
	{
		if (p_bingo[i] == -1)
		{
			++tempcrossLT;
		}
	}

	for (int i = 4; i < 21; i += 4)
	{
		if (p_bingo[i] == -1)
		{
			++tempcrossRT;
		}
	}

	if (tempcrossLT == 5)
	{
		++bingocount;
	}
	if (tempcrossRT == 5)
	{
		++bingocount;
	}

	return bingocount;
}

int GetBingoCount(int (*p_bingo)[BIGOSIZE] )
{
	int bingocount = 0;
	// ��ü������ �Ǿ��ִ°�

	int xline = 0;
	int yline = 0;
	for (int i = 0; i < 5; i++)
	{
		yline = xline = 0;

		for (int j = 0; j < 5; j++)
		{
			// x�� ���� �ڷ�
			if (p_bingo[i][j] == -1)
			{
				++xline;
			}
			if (p_bingo[j][i] == -1)
			{
				++yline;
			}
		}

		if (xline == 5)
		{
			++bingocount;
		}

		if (yline == 5)
		{
			++bingocount;
		}

	}


	// ũ�ν� �޻��, �������
	int tempcrossLT = 0;
	int tempcrossRT = 0;
	for (int i = 0; i < 5; i++)
	{
		if (p_bingo[i][i] == -1)
		{
			++tempcrossLT;
		}
		if (p_bingo[5 - i - 1][i] == -1)
		{
			++tempcrossRT;
		}
	}
	if (tempcrossLT == 5)
	{
		++bingocount;
	}
	if (tempcrossRT == 5)
	{
		++bingocount;
	}

	return bingocount;
}


void SetBingoData( int* p_bingo, int p_val )
{
	for (int y = 0; y < 5; y++)
	{
		for (int x = 0; x < 5; x++)
		{
			if (p_bingo[y * BIGOSIZE + x] == p_val)
			{
				p_bingo[y * BIGOSIZE + x] = -1;
			}
		}
	}
}

int GetAIVal(int* p_aibingo)
{

	int tempstarcount = 0;
	int lineat = 0;


	int xcount = 0;
	int ycount = 0;
	for (int i = 0; i < 5; i++)
	{
		ycount = xcount = 0;
		for (int j = 0; j < 5; j++)
		{
			// x�����
			if (p_aibingo[i * 5 + j] == -1)
			{
				++xcount;
			}

			if (p_aibingo[i + 5 * j] == -1)
			{
				++ycount;
			}
		}

		if (ycount <5 && tempstarcount < ycount)
		{
			tempstarcount = ycount;
			lineat = i + 5;
		}

		if (xcount < 5 && tempstarcount < xcount)
		{
			tempstarcount = xcount;
			lineat = i;
		}

	}


	// ũ�ν� �κ� 
	// lt
	xcount = 0;
	for (int i = 0; i < 25; i += 6)
	{
		if (p_aibingo[i] == -1 )
		{
			++xcount;
		}
	}
	if (xcount <5 
		&& tempstarcount < xcount)
	{
		tempstarcount = xcount;
		lineat = 10;
	}

	// rt
	xcount = 0;
	for (int i = 4; i < 21; i += 4)
	{
		if (p_aibingo[i] == -1)
		{
			++xcount;
		}
	}
	if (xcount < 5
		&& tempstarcount < xcount)
	{
		tempstarcount = xcount;
		lineat = 11;
	}


	
	int at = 0;
	int temparr[5] = { 0, };
	// x���϶� 0~4
	if ( lineat < 5 )
	{
		for (int i = 0; i < 5; i++)
		{
			if ( p_aibingo[(lineat * 5) + i] > 0)
			{
				temparr[at++] = p_aibingo[(lineat * 5) + i];
			}
		}
	}
	else if (lineat < 10 )
	{
		// y ��
		for (int  i = 0; i < 5; i++)
		{
			int tempval = p_aibingo[ (lineat - 5) + (i * 5) ];
			if (tempval > 0)
			{
				temparr[at++] = tempval;
			}
		}
	}
	else if (lineat == 10)
	{
		for (int i = 0; i < 25; i += 6)
		{
			if (p_aibingo[i] > 0)
			{
				temparr[at++] = p_aibingo[i];
			}
		}
	}
	else if (lineat == 11)
	{
		for (int i = 4; i < 21; i += 4)
		{
			if (p_aibingo[i] > 0)
			{
				temparr[at++] = p_aibingo[i];
			}
		}
	}

	return temparr[rand() % at];
}

int GetEaseAIVal( int* p_aibingo )
{
	int outat = -1;

	int loopcount = 0;

	if (false)
	{
		// ���� ��� �������� ������ ���ư��� �ִٴ°�
		while (true)
		{
			// 10������ ���ư��� ����
			int randat = rand() % 25;
			if (p_aibingo[randat] > 0)
			{
				cout << "���� : " << loopcount << endl;
				return p_aibingo[randat];
			}
			++loopcount;
		}
	}
	else
	{
		int at = 0;
		int temparr[25] = { 0, };
		for (int i = 0; i < 25; i++)
		{
			if (p_aibingo[i] > 0)
			{
				temparr[at++] = p_aibingo[i];
			}
		}

		if (at <= 0)
		{
			return -1;
		}

		int randat = rand() % at;
		return temparr[ rand() % at ];
	}


}

void main()
{
	srand(time(NULL));

	int tempval = 1;
	InitTest( &tempval );

	int bingo2byarr[BIGOSIZE][BIGOSIZE] = { 0, };
	int aibingoarr[BIGOSIZE][BIGOSIZE] = { 0, };

	InitBingo( bingo2byarr, true );
	InitBingo(aibingoarr, false);


	int ailevel = 0;
	cout << "AI ������ 0=easy, 1=hard : ";
	//cin >> ailevel;
	ailevel = 1;

	while (true)
	{
		system("cls");

		// �÷��̾� ����Ʈ
		BingoPrint( &bingo2byarr[0][0] );
		int bingocount = GetBingoCount( &bingo2byarr[0] );
		cout << "�������� : " << bingocount<< endl;

		
		// ai �κ� -----------------------------------------------
		// AI ȭ�� ���
		cout << endl << endl << "------AI------------" << endl;
		BingoPrint( (int*)aibingoarr );
		int aibingocount = GetBingoCount( aibingoarr[0] );


		cout << "AI�������� : " << aibingocount << endl;

		// ai �κ� -----------------------------------------------


		if (bingocount >= 4)
		{
			cout << "�÷��̾� �¸� : ";
			break;
		}

		if (aibingocount >= 4)
		{
			cout << "AI�¸� : ";
			break;
		}



		// �Է� �ޱ�
		int inputval = -1;
		cout << endl << "�÷��̾� ���ڸ� �Է��ϼ��� : ";
		cin >> inputval;

		// ������ ����
		SetBingoData( bingo2byarr[0], inputval);
		// AI �� �� ����
		SetBingoData( aibingoarr[0], inputval);
		


		// AI �� ���
		int aival = -1;
		if (ailevel != 0)
		{
			aival = GetAIVal(aibingoarr[0]);
			
		}
		else
		{
			aival = GetEaseAIVal(aibingoarr[0]);
		}


		if (aival <= -1)
		{
			//cout << endl << "�÷��̾� ���ڸ� �Է��ϼ��� : ";
			assert(0 && "AI �� �̻���");
		}


		// ������ ����
		SetBingoData(bingo2byarr[0], aival);
		// AI �� �� ����
		SetBingoData(aibingoarr[0], aival);
		

	}

}

void BingoPrint( int* bingo2byarr )
{
	// ȭ�� ���
	for (int y = 0; y < 5; y++)
	{
		for (int x = 0; x < 5; x++)
		{
			if (bingo2byarr[(y * 5) + x] <= -1)
			{
				cout << "*" << '\t';
			}
			else
			{
				cout << bingo2byarr[(y * 5) + x] << '\t';
			}

		}
		cout << endl; // ���Ϳ�Ȱ
	}
}

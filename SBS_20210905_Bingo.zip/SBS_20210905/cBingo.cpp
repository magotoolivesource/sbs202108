#include "cBingo.h"
#include <iostream>


using namespace std;
void cBingo::TestFN()
{
	cout << "TestFN Call" << endl;
}



void cBingo::PrintBingo()
{
	int* bingo2byarr = &m_Bingo2byarr[0][0];

	// ȭ�� ���
	for (int y = 0; y < 5; y++)
	{
		for (int x = 0; x < 5; x++)
		{
			if (bingo2byarr[(y * 5) + x] <= -1)
			{
				cout << "*" << '\t';
			}
			else
			{
				cout << bingo2byarr[(y * 5) + x] << '\t';
			}
		}
		cout << endl; // ���Ϳ�Ȱ
	}

}


int cBingo::GetBingoCount()
{
	UpdateBingoCount();
	return m_BingoCount;
}

void cBingo::UpdateBingoCount()
{
	int bingocount = 0;
	// ��ü������ �Ǿ��ִ°�

	int xline = 0;
	int yline = 0;
	for (int i = 0; i < 5; i++)
	{
		yline = xline = 0;

		for (int j = 0; j < 5; j++)
		{
			// x�� ���� �ڷ�
			if (m_Bingo2byarr[i][j] == -1)
			{
				++xline;
			}
			if (m_Bingo2byarr[j][i] == -1)
			{
				++yline;
			}
		}

		if (xline == 5)
		{
			++bingocount;
		}

		if (yline == 5)
		{
			++bingocount;
		}

	}


	// ũ�ν� �޻��, �������
	int tempcrossLT = 0;
	int tempcrossRT = 0;
	for (int i = 0; i < 5; i++)
	{
		if (m_Bingo2byarr[i][i] == -1)
		{
			++tempcrossLT;
		}
		if (m_Bingo2byarr[5 - i - 1][i] == -1)
		{
			++tempcrossRT;
		}
	}
	if (tempcrossLT == 5)
	{
		++bingocount;
	}
	if (tempcrossRT == 5)
	{
		++bingocount;
	}

	m_BingoCount = bingocount;
}

cBingo::cBingo() : m_BingoCount(0)
{
	m_BingoCount = 0;

	InitBingo();
}

cBingo::~cBingo()
{
}

void cBingo::InitBingo(bool p_isrand)
{
	for (int y = 0; y < 5; y++)
	{
		for (int x = 0; x < 5; x++)
		{
			m_Bingo2byarr[y][x] = ((y * 5) + x) + 1;
		}
	}


	if (p_isrand)
	{
		for (int i = 0; i < 15; i++)
		{
			// ���� ��ġ
			int x = i % 5;
			int y = int(i / 5);

			// ������ġ
			int temprand = rand() % 25;
			int sx = temprand % 5;
			int sy = (int)(temprand / 5);

			// �� ���� 
			CoreFN::SwapVal(m_Bingo2byarr[y][x], m_Bingo2byarr[sy][sx]);
		}
	}

}


